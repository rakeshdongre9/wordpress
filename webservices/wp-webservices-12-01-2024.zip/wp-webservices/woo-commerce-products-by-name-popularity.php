<?php
require_once ('../wp-config.php'); // replace with your WordPress installation path
// https://suuqonline.com/wp-webservices/woo-commerce-products-by-name-popularity.php?product_name=a&user_id=1&get_popular_products

function get_products_by_popularity($image_not_available) {
    $user_id = isset($_REQUEST['user_id']) ? $_REQUEST['user_id'] : 0;

    global $wpdb;

     $product_query = "
        SELECT p.ID
        FROM {$wpdb->posts} p
        INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
        WHERE p.post_type = 'product'
        AND p.post_status = 'publish'
        AND pm.meta_key = 'total_sales' 
        ORDER BY pm.meta_value DESC
    ";
    
    

    $product_ids = $wpdb->get_col($product_query);
    
    
    

    if (empty($product_ids)) {
        return array('error' => true, 'message' => 'Products not found');
    }

    $products_data = array();

    foreach ($product_ids as $product_id) {
        $product = wc_get_product($product_id);

        if ($product) {
            $image_id = $product->get_image_id();

            if ($image_id) {
                $image_url = wp_get_attachment_url($image_id);
            } else {
                $image_url = $image_not_available;
            }

            $product_data = array(
                'id'    => $product_id,
                'name'  => $product->get_name(),
                'image' => $image_url,
                'price' => $product->get_price(),
            );

            $products_data[] = $product_data;
        }
    }

    return $products_data;
}

// Check if a 'get_popular_products' flag is provided in the request
if (isset($_GET['get_popular_products'])) {
    // Get popular products information
    $popular_products = get_products_by_popularity($image_not_available);

    if (empty($popular_products)) {
        $response = array('result' => [], 'message' => 'unsuccess', 'status' => '0');
    } else {
        $response = array('result' => $popular_products, 'message' => 'Success', 'status' => '1');
    }

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array('result' => [], 'message' => 'unsuccess', 'status' => '0');
    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}
