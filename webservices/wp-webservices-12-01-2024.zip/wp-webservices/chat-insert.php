<?php



require_once "../wp-config.php";

//https://technorizen.com/_angotech_homol1/wp-webservices/chat-insert.php?sender_id=2&receiver_id=2&message=hi

$sender_id = $_REQUEST['sender_id'];
$receiver_id = $_REQUEST['receiver_id'];
$message = $_REQUEST['message'];

$date_time = date('Y:m:d H:i:s');

 $sql = "INSERT INTO `dNvuK_chat` (`chat_receiver_id`, `chat_sender_id`, `chat_seen_status`, `chat_text`,`chat_date_time`) VALUES ('$receiver_id', '$sender_id', 'UNSEEN', '$message', '$date_time');";

$check_events = $wpdb->query($sql);
if ($check_events) {
    $msg["result"] = "1";
    $msg["message"] = "successful";
    $msg["status"] = "1";
    header("Content-type:application/json");
    echo json_encode($msg);
    die();
} else {
    $msg["result"] = [];
    $msg["message"] = "unsuccessful";
    $msg["status"] = "0";
    header("Content-type:application/json");
    echo json_encode($msg);
}

?>