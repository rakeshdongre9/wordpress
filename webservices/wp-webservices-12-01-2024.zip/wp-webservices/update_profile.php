<?php
require_once('../wp-config.php');

$user_id = $_REQUEST['user_id'];
$username = $_REQUEST['username'];
$email = $_REQUEST['email'];
$mobile = $_REQUEST['mobile'];
$dob = $_REQUEST['dob'];

 $sql = "SELECT * FROM `wp_users` WHERE `ID` = '$user_id'";

$check_login = $wpdb->get_results($sql);


if ($check_login) {
    

        update_user_meta($user_id, 'mobile', $mobile);
        update_user_meta($user_id, 'dob', $dob);

        if (isset($_FILES['image'])) {
            $n = rand(0, 100000);
            $img = "user_IMG_" . $n . '.png';
            move_uploaded_file($_FILES['image']['tmp_name'], "../wp-uploads/user/" . $img);
            
            $meta_key = 'image'; 
            $new_meta_value = $img; 

            update_user_meta($user_id, $meta_key, $new_meta_value);
            
        } else {
            $UiMAGE1 = $UiMAGE;
        }

        $msg['result'] = 'Update Profile Successfully...';
        $msg["message"] = "SUCCESS";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg);
        
} else {
        $msg['result'] = "Unsuccessful";
        $msg["message"] = "No Data Found";
        $msg["status"] = "0";
        header('Content-type:application/json');
        echo json_encode($msg);
}

