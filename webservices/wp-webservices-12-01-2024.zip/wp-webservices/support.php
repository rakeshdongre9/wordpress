<?php

require_once("../wp-load.php");

//https://technorizen.com/_angotech_homol1/wp-webservices/support.php?support_name=name&support_email=email&support_brief=brief&support_details=details

function insert_support_record() {
    global $wpdb;

    $table_name = 'wpuo_support';

    $support_name = sanitize_text_field($_REQUEST['support_name']);
    $support_email = sanitize_email($_REQUEST['support_email']);
    $support_brief = sanitize_text_field($_REQUEST['support_brief']);
    $support_details = sanitize_textarea_field($_REQUEST['support_details']);


     
    if ( empty($support_email)) {
        $msg["result"] = [];
        $msg["message"] = "Email required parameters";
        $msg["status"] = "0";
        return $msg;
    }
    
    if (empty($support_name)  ) {
        $msg["result"] = [];
        $msg["message"] = "Missing required name";
        $msg["status"] = "0";
        return $msg;
    }
 
    if (empty($support_brief)  ) {
        $msg["result"] = [];
        $msg["message"] = "Missing brief";
        $msg["status"] = "0";
        return $msg;
    }
    
    
    if (empty($support_details)  ) {
        $msg["result"] = [];
        $msg["message"] = "Missing details";
        $msg["status"] = "0";
        return $msg;
    }
  
    

    $data = array(
        'support_name' => $support_name,
        'support_email' => $support_email,
        'support_brief' => $support_brief,
        'support_details' => $support_details
    );

    $wpdb->insert($table_name, $data);

    if ($wpdb->insert_id) {
        $msg["result"] = ['support_id' => $wpdb->insert_id];
        $msg["message"] = "Record inserted successfully";
        $msg["status"] = "1";
    } else {
        $msg["result"] = [];
        $msg["message"] = "Failed to insert record";
        $msg["status"] = "0";
    }

    return $msg;
}

$result = insert_support_record();

header("Content-type: application/json");
echo json_encode($result);
die();
?>