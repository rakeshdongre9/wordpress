<?php
require_once('../wp-config.php');

//https://suuqonline.com/wp-webservices/woo-commerce-products-by-name-average-rating.php?product_name=a&user_id=1&get_top_rated_products

function get_products_by_average_rating($image_not_available) {
    global $wpdb;

     $product_query = "
        SELECT p.ID
        FROM {$wpdb->posts} p
        LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_wc_average_rating'
        WHERE p.post_type = 'product'
        AND p.post_status = 'publish'
        ORDER BY CAST(pm.meta_value AS DECIMAL(3, 2)) DESC
    ";
    
    //die;

    $product_ids = $wpdb->get_col($product_query);

    if (empty($product_ids)) {
        return array('error' => true, 'message' => 'Products not found');
    }

    $products_data = array();

    foreach ($product_ids as $product_id) {
        $product = wc_get_product($product_id);

        if ($product) {
            $image_id = $product->get_image_id();

            if ($image_id) {
                $image_url = wp_get_attachment_url($image_id);
            } else {
                $image_url = $image_not_available;
            }

            $product_data = array(
                'id'    => $product_id,
                'name'  => $product->get_name(),
                'image' => $image_url,
                'price' => $product->get_price(),
                'average_rating' => $product->get_average_rating(), // Add average rating to the result
            );
            
            
            global $wpdb;
            // Check if the record already exists
            $d = "SELECT * FROM `wp_yith_wcwl` WHERE `prod_id` = '$product_id' AND `user_id` = '" . $_REQUEST['user_id'] . "'";
            $existing_record = $wpdb->get_row($d);
            if ($wpdb->num_rows > 0) {
                $product_data['wish_status'] = true;
            } else {
                $product_data['wish_status'] = false;
            }
            
            

            $products_data[] = $product_data;
        }
    }

    return $products_data;
}

// Check if a 'get_top_rated_products' flag is provided in the request
if (isset($_GET['get_top_rated_products'])) {
    // Get top-rated products information
    $top_rated_products = get_products_by_average_rating($image_not_available);

    if (empty($top_rated_products)) {
        $response = array('result' => [], 'message' => 'unsuccess', 'status' => '0');
    } else {
        $response = array('result' => $top_rated_products, 'message' => 'Success', 'status' => '1');
    }

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array('result' => [], 'message' => 'unsuccess', 'status' => '0');
    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}
?>