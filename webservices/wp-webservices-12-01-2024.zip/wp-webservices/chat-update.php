<?php

require_once "../wp-config.php";


//https://technorizen.com/_angotech_homol1/wp-webservices/chat-update.php?sender_id=2&receiver_id=2&message=hi&chat_id=2&action=update

$chat_id = $_REQUEST['chat_id'];

$sender_id = $_REQUEST['sender_id'];
$receiver_id = $_REQUEST['receiver_id'];
$message = $_REQUEST['message'];

$date_time = date('Y:m:d H:i:s');




 $sql = "UPDATE `dNvuK_chat` SET `chat_receiver_id`='$receiver_id',`chat_sender_id`='$sender_id',`chat_text`='$message',  `chat_date_time`= '$date_time' WHERE `chat_id`='$chat_id'";

$check_events = $wpdb->query($sql);


if ($check_events) {

    $msg["result"] = $check_events;
    $msg["message"] = "successful";
    $msg["status"] = "1";
    header("Content-type:application/json");
    echo json_encode($msg);
    die();
} else {
    $msg["result"] = [];
    $msg["message"] = "unsuccessful";
    $msg["status"] = "0";
    header("Content-type:application/json");
    echo json_encode($msg);
}


?>