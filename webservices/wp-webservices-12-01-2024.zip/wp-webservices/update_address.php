<?php 

require_once('../wp-config.php');

            
            $shipping_first_name = $_REQUEST['shipping_first_name'];
            $shipping_last_name = $_REQUEST['shipping_last_name'];
            $shipping_address_1 = $_REQUEST['shipping_address_1'];
            $shipping_address_2 = $_REQUEST['shipping_address_2'];
            $shipping_country = $_REQUEST['shipping_country'];
            $shipping_state = $_REQUEST['shipping_state'];
            $shipping_city = $_REQUEST['shipping_city'];
            $shipping_phone = $_REQUEST['shipping_phone'];
            $user_id = $_REQUEST['user_id'];
            
            
              

  $check_login = $wpdb->get_results( "SELECT  *  FROM  `wpuo_users`  WHERE  `ID`  =  '$user_id' ");
  

 
 if($check_login)
    
    {
        
           update_user_meta($user_id, 'shipping_first_name', $shipping_first_name);
           update_user_meta($user_id, 'shipping_last_name', $shipping_last_name);
           update_user_meta($user_id, 'shipping_address_1', $shipping_address_1);
           update_user_meta($user_id, 'shipping_address_2', $shipping_address_2);
           update_user_meta($user_id, 'shipping_country', $shipping_country);
           update_user_meta($user_id, 'shipping_state', $shipping_state);
           update_user_meta($user_id, 'shipping_city', $shipping_city);
           update_user_meta($user_id, 'shipping_phone', $shipping_phone);
        

    //  $user_imageC = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'user_image'  ");
    //  $user_imageC1 = json_decode(json_encode($user_imageC), true);
    //  $imageID = $user_imageC1[0]['umeta_id'];
    //  $UiMAGE = $user_imageC1[0]['meta_value'];
   
    //   $dob = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'dob'  ");
    //   $dobc = json_decode(json_encode($dob), true);
    //   $dobID = $dobc[0]['umeta_id'];
       
    //     $mobileC = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'mobile'  ");
    //   $mobileCA = json_decode(json_encode($mobileC), true);
    //   $mobileID = $mobileCA[0]['umeta_id'];

   if($check_login)
   {
       
        // $wpdb->get_results( "UPDATE `wpuo_users` SET `user_login`= '$username',`user_email` = '$email' WHERE `ID` = '$user_id' ");
        
        // $wpdb->get_results( "UPDATE `wpuo_usermeta` SET `meta_value`= '$dobdata2' WHERE `user_id` = '$user_id' AND `umeta_id` = '$dobID' ");
        
        // $wpdb->get_results( "UPDATE `wpuo_usermeta` SET `meta_value`= '$mobile' WHERE `user_id` = '$user_id' AND `umeta_id` = '$mobileID' ");
        
    //     if (isset($_FILES['image']))
    //         	{
    //                                  //  unlink('uploads/images/'.$login[0]['image']);
    //         		$n = rand(0, 100000);
    //         		$img = "user_IMG_" . $n . '.png';
    //         		move_uploaded_file($_FILES['image']['tmp_name'], "../wp-content/uploads/images/" . $img);
    //         		$UiMAGE1 = $img;        
    //         	}
            	
    //         	else
    //         	{
    //         	    	$UiMAGE1 = $UiMAGE; 
    //         	}
            	
    // 	$wpdb->get_results( "UPDATE `wpuo_usermeta` SET `meta_value`= '$UiMAGE1' WHERE `user_id` = '$user_id' AND `umeta_id` = '$imageID' ");
       
        
        
        
        $msg['result'] = 'Update address Successfully...';
        $msg["message"] = "Success";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg); 

       
   }
   else
   {
        $msg['result'] = "Unsuccess";
        $msg["message"] = "No Data Found";
        $msg["status"] = "0";
        header('Content-type:application/json');
        echo json_encode($msg);
   }
   
   // SELECT * FROM `dNvuK_usermeta` WHERE `umeta_id` = '320' AND `user_id` = 21 AND `meta_key` = 'otp'
   
   
    
       
    }
    
    else
    {
         $msg['result'] = "User Id Not Found";
        $msg["message"] = "No Data Found";
        $msg["status"] = "0";
        header('Content-type:application/json');
        echo json_encode($msg);
    }





?>