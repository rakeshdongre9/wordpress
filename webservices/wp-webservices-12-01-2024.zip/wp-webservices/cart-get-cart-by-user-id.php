<?php

// https://suuqonline.com/wp-webservices/cart-get-cart-by-user-id.php?user_id=30

require_once('../wp-config.php'); // replace with your WordPress installation path

$user_id = $_REQUEST['user_id']; // Replace with the desired user ID

global $wpdb;

$user_id = $_REQUEST['user_id']; // Replace 123 with the actual user ID

// Function to get product details by ID
function get_product_by_id($product_id, $variation_id) {
    $product = wc_get_product($product_id);

    if (!$product) {
        return array(
            'error' => true,
            'message' => 'Product not found',
        );
    }

    $product_data = array(
        'id' => $product_id,
        'name' => $product->get_name(),
        'permalink' => $product->get_permalink(),
        'images' => array(),
        'meta' => array(),
        'price' => $product->get_price(),
        'regular_price' => $product->get_regular_price(),
        'sale_price' => $product->get_sale_price(),
        //'description' => $product->get_description(),
        'attributes' => $product->get_attributes(),
        'related_products' => array(),
        'recommended_products' => array(),
    );

    $product_images = $product->get_gallery_image_ids();

    foreach ($product_images as $image_id) {
        $image_url = wp_get_attachment_image_src($image_id, 'full');
        if ($image_url) {
            $product_data['images'][] = $image_url[0];
        }
    }

    $image_id = $product->get_image_id();
    $image_status = wp_get_attachment_image_url($image_id, 'full');
    $product_data['main_image'] = ($image_status != NULL) ? wp_get_attachment_image_url($image_id, 'full') : '';

    // Get additional metadata
    $product_meta = get_post_meta($product_id);
    foreach ($product_meta as $meta_key => $meta_value) {
        //$product_data['meta'][$meta_key] = $meta_value[0];
    }

    // Get variations if product is variable
    if ($product->is_type('variable') && !empty($variation_id)) {
        $variation_product = wc_get_product($variation_id);
        $variation_image_id = $variation_product->get_image_id();
        $variation_image_url = ($variation_image_id != 0) ? wp_get_attachment_image_url($variation_image_id, 'full') : '';

        $product_data['variations'][] = array(
            'id' => $variation_id,
            'price' => $variation_product->get_price(),
            'regular_price' => $variation_product->get_regular_price(),
            'image' => $variation_image_url,
            // Add any other variation details you need
        );
    }

    // Get related products
    $related_ids = $product->get_cross_sell_ids();
    $related_products = array();

    foreach ($related_ids as $related_id) {
        $related_product = get_product_by_id($related_id, '');
        if (!isset($related_product['error'])) {
            $related_products[] = $related_product;
        }
    }

    $product_data['related_products'] = $related_products;

    // Get recommended products
    $recommended_ids = $product->get_upsell_ids();
    $recommended_products = array();

    foreach ($recommended_ids as $recommended_id) {
        $recommended_product = get_product_by_id($recommended_id, '');
        if (!isset($recommended_product['error'])) {
            $recommended_products[] = $recommended_product;
        }
    }

    $product_data['recommended_products'] = $recommended_products;

    return $product_data;
}

// Prepare the SQL query
$query = $wpdb->prepare(
    "SELECT * FROM wpuo_custom_cart WHERE cart_user_id = %d",
    $user_id
);

// Execute the query
$results = $wpdb->get_results($query);

// Initialize response array
$response = array();

// Check if there are any cart items
if (!empty($results)) {
    // Iterate through the cart items
    
    
    
    foreach ($results as $result) {
        // Access the cart item properties
        $cart_product_id = $result->cart_product_id;
        $cart_variation_id = $result->cart_variation_id;
        $cart_quantity = $result->cart_quantity;

        // Get product details
        $product_data = get_product_by_id($cart_product_id, $cart_variation_id);

        if (!isset($product_data['error'])) {

        // Add cart item to the response
        $response[] = array(
            'product' => $product_data,
            'quantity' => $cart_quantity
        );
        
        }
    }
    
    
         $final_total_price = array();
         
    foreach($response as $product_data_in){
        
         if(isset($product_data_in['product']['variations'][0]['price'])){
             $final_total_price[] = $product_data_in['product']['variations'][0]['price'] * $product_data_in['quantity'];
         }else{
             $final_total_price[] = $product_data_in['product']['price'] * $product_data_in['quantity'];
         }

    }

    //print_r($final_total_price);

    $json['total_price'] = array_sum($final_total_price);
    $json['total_tax'] = 0;
    $json['total_shipping'] = 0;
    $json['total_sub_total'] = 0;



    $json['result'] = $response;
    $json['message'] = 'Cart items retrieved successfully';
    $json['status'] = '1';
} else {
    $json['result'] = array();
    $json['message'] = 'Cart is empty';
    $json['status'] = '0';
}

// Output the result as JSON
header('Content-Type: application/json');
echo json_encode($json);

?>