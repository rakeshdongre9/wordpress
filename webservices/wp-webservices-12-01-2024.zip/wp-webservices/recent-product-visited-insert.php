<?php

//https://technorizen.com/_angotech_homol1/wp-webservices/recent-product-visited-insert.php?user_id=1&prod_id=2

require_once('../wp-config.php'); // replace with your WordPress installation path

global $wpdb;

$table_name = 'wpuo_recent_visits_list';
    
    
$user_id = $_REQUEST['user_id'];
$prod_id = $_REQUEST['prod_id'];


// Insert the product into the wpuo_recent_product_list table
$sql = "INSERT INTO `wpuo_recent_visits_list` ( `user_id`, `prod_id`) 
        VALUES ('$user_id', '$prod_id')";
$wpdb->query($sql);

// Check if the insertion was successful
if ($wpdb->insert_id === 0) {
    // Handle the case where insertion failed
    $response = array(
        'message' => 'Failed to add recent product',
        'status' => '0'
    );
} else {
    // Return a success message for adding the new product
    $response = array(
        'message' => 'Recent product added successfully',
        'status' => '1'
    );
}

// Encode the response as JSON and output it
echo json_encode($response);

    
    
      
   
?>