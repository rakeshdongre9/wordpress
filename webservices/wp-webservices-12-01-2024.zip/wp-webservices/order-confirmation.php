<?php

// https://SERVER-PHP-7-3.TECHNORIZEN.COM/_angotech_homol1/wp-webservices/order-confirmation.php?order_id=8015

// Include WordPress and WooCommerce core files
require_once('../wp-config.php');

global $wpdb;

// Check if an order ID is provided in the request
if (isset($_REQUEST['order_id'])) {
    $order_id = intval($_REQUEST['order_id']);
    
    // Get the order object
    $order = wc_get_order($order_id);
    
    // Check if the order exists
    if ($order) {
        // Update the order status to "processing"
        $order->update_status('processing');
        
        // Get order data after updating
        $order_data = $order->get_data();
        
        // Retrieve customer_id from wpuo_wc_order_product_lookup table
        $table_name = 'wpuo_wc_order_product_lookup';
        $query = $wpdb->prepare(
            "SELECT * FROM $table_name WHERE order_id = %d LIMIT 1",
            $order_id
        );
        
        $result = $wpdb->get_row($query);
        
        // Create a response array with relevant order information, including the updated status
        $response = array(
            'order_id' => $order_id,
            'status' => 'processing', // The order status has been updated
            'total' => $order->get_total(),
            'customer_id' => $result->customer_id,
            'shipping_amount' => $result->shipping_amount,
            'product_qty' => $result->product_qty,
            // Add more fields as needed
        );
        
        // Output the response as JSON
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // Order not found
        http_response_code(404);
        echo json_encode(array('error' => 'Order not found'));
    }
} else {
    // Order ID not provided in the request
    http_response_code(400);
    echo json_encode(array('error' => 'Order ID is missing'));
}
?>