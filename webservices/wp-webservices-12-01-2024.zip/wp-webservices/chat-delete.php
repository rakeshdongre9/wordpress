<?php

require_once "../wp-config.php";

//https://technorizen.com/_angotech_homol1/wp-webservices/chat-delete.php?chat_id=2&action=delete

$chat_id = $_REQUEST['chat_id'];

$sql = "DELETE FROM `dNvuK_chat` WHERE `chat_id`='$chat_id';";
$check_events = $wpdb->query($sql);
    
if ($check_events) {
    $msg["result"] = "successful";
    $msg["message"] = "successful";
    $msg["status"] = "1";
    header("Content-type:application/json");
    echo json_encode($msg);
    die();
} else {
    $msg["result"] = "unsuccessful";
    $msg["message"] = "unsuccessful";
    $msg["status"] = "0";
    header("Content-type:application/json");
    echo json_encode($msg);
}

?>