<?php


require_once('../wp-config.php'); // replace with your WordPress installation path



// Replace 'mega-menu' with the name of your menu location
$menu_location = 'mega-menu';

// Get the menu items for the specified menu location
$menu_items = wp_get_nav_menu_items($menu_location);

// Create an associative array to store the menu items hierarchically
$menu_tree = array();

// Create a function to build the menu tree recursively
function build_menu_tree_mega($menu_items, $parent_id = 0) {
    $menu_tree = array();

    foreach ($menu_items as $menu_item) {
        if ($menu_item->menu_item_parent == $parent_id) {
            $menu_tree_item = (array)$menu_item;
            $menu_tree_item['children'] = build_menu_tree_mega($menu_items, $menu_item->ID);
            $menu_tree[] = $menu_tree_item;
        }
    }

    return $menu_tree;
}

// Build the menu tree starting with parent items (parent_id = 0)
$menu_tree = build_menu_tree_mega($menu_items, 0);

// Now, $menu_tree contains the hierarchical menu items in an array format
// You can use this array to display or process the menu items as needed

$result['data'] = $menu_tree;
$result['success'] = 1;
  // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($result);
    die;
    
?>