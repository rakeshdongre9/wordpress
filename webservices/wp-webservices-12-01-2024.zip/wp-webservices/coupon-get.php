<?php

//https://technorizen.com/_angotech_homol1/wp-webservices/coupon-get.php

require_once('../wp-config.php'); // replace with your WordPress installation path


// Retrieve the coupon list
$args = array(
    'post_type' => 'shop_coupon',
    'posts_per_page' => -1,
);

$coupons = get_posts($args);

$coupon_list = array();
foreach ($coupons as $coupon) {
    $coupon_data = array(
        'id' => $coupon->ID,
        'code' => $coupon->post_title,
        'description' => $coupon->post_excerpt,
        'usage_limit' => get_post_meta($coupon->ID, 'usage_limit', true),
        'usage_limit_per_user' => get_post_meta($coupon->ID, 'usage_limit_per_user', true),
        'discount_type' => get_post_meta($coupon->ID, 'discount_type', true),
        'amount' => get_post_meta($coupon->ID, 'coupon_amount', true),
        'expiry_date' => get_post_meta($coupon->ID, 'expiry_date', true),
        'individual_use' => get_post_meta($coupon->ID, 'individual_use', true),
        'exclude_sale_items' => get_post_meta($coupon->ID, 'exclude_sale_items', true),
        'free_shipping' => get_post_meta($coupon->ID, 'free_shipping', true),
        // Add more details as needed
    );

    $coupon_list[] = $coupon_data;
}

$response = array(
    'coupons' => $coupon_list,
    'message' => 'Coupon details retrieved successfully',
    'status' => '1'
);

// Output the result as JSON
header('Content-Type: application/json');
echo json_encode($response);
die;
?>