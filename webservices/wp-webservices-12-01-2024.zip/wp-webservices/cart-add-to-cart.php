<?php

//https://suuqonline.com/wp-webservices/cart-add-to-cart.php?product_id=8427&variation_id=8727&quantity=2&user_id=1

require_once('../wp-config.php'); // replace with your WordPress installation path
global $wpdb;

// Retrieve values from $_REQUEST
$cart_product_id = $_REQUEST['product_id'];
$cart_variation_id = $_REQUEST['variation_id'];
$cart_quantity = $_REQUEST['quantity'];
$cart_user_id = $_REQUEST['user_id'];

// Check if the combination of cart_product_id, cart_variation_id, and cart_user_id already exists
$check_query = $wpdb->prepare(
    "SELECT COUNT(*) FROM wpuo_custom_cart
    WHERE cart_product_id = %s AND cart_variation_id = %s AND cart_user_id = %s",
    $cart_product_id,
    $cart_variation_id,
    $cart_user_id
);

$existing_count = $wpdb->get_var($check_query);

if ($existing_count > 0) {
        $response = array(
        'result' => 0,
        'message' => 'Data failed in the custom table',
        'status' => '1'
    );
    
    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    
} else {
    // Combination does not exist, perform an insert
    $insert_query = $wpdb->prepare(
        "INSERT INTO wpuo_custom_cart (cart_product_id, cart_variation_id, cart_quantity, cart_user_id)
        VALUES (%s, %s, %s, %s)",
        $cart_product_id,
        $cart_variation_id,
        $cart_quantity,
        $cart_user_id
    );

    $result = $wpdb->query($insert_query);
    
    
        $response = array(
        'result' => 0,
        'message' => 'Data inserted in the custom table',
        'status' => '1'
    );
    
    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    
}



