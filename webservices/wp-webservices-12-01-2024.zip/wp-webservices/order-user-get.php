<?php
// https://SERVER-PHP-7-3.TECHNORIZEN.COM/_angotech_homol1/wp-webservices/order-user-get.php?user_id=1

require_once('../wp-config.php');

// Define the user ID for which you want to retrieve orders
$user_id = $_REQUEST['user_id']; // Change this to the desired user's ID

// Get all orders for the user
$customer_orders = wc_get_orders(array(
    'customer' => $user_id,
    'status' => array('completed', 'processing', 'on-hold'), // You can specify the order statuses you're interested in
));

// Initialize an empty array to store order data
$order_data = array();

// Loop through the orders and retrieve relevant information
foreach ($customer_orders as $order) {
    // Get additional order details like image, price, etc.
    $order_details = array(
        'order_id' => $order->get_id(),
        'order_status' => $order->get_status(),
        'order_total' => strip_tags(wc_price($order->get_total())),
        // Add more order details here as needed
    );

    // Add order details to the array
    $order_data[] = $order_details;
}

// Encode the order data into JSON format
$json_response = json_encode($order_data);

// Set the response content type to JSON
header('Content-Type: application/json');

// Output the JSON response
echo $json_response;
?>