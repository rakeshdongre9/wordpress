<?php
//https://server-php-7-3.technorizen.com/_angotech_homol1/wp-webservices/order-create.php?product_id=8427,8533&user_id=4&variation_id=8727,&quantity=1,2
//https://suuqonline.com/wp-webservices/order-create.php?product_id=8427,8533&user_id=1&variation_id=8727,&quantity=1,2

require_once ('../wp-config.php');
$product_ids = isset($_REQUEST['product_id']) ? explode(',', $_REQUEST['product_id']) : array();
$user_id = isset($_REQUEST['user_id']) ? intval($_REQUEST['user_id']) : 0;
$variation_ids = isset($_REQUEST['variation_id']) ? explode(',', $_REQUEST['variation_id']) : array();
$quantities = isset($_REQUEST['quantity']) ? explode(',', $_REQUEST['quantity']) : array();

// Create a new instance of the WC_Order class
$order = new WC_Order();
// Set the order data using $_REQUEST or any other source
$order_data = array('customer_id' => $user_id,
// Populate other order data fields as needed
);

// Save the order data
$order->set_props($order_data);
$order->save();

// Loop through the products and quantities
foreach ($product_ids as $key => $product_id) {
    $product_id = intval($product_id);
    $quantity = isset($quantities[$key]) ? intval($quantities[$key]) : 0;
    $variation_id = isset($variation_ids[$key]) ? intval($variation_ids[$key]) : 0;
    // Retrieve the product and variation
    $product = wc_get_product($product_id);
    $variation = wc_get_product($variation_id);
    // Add the main product to the order
    if ($product && $quantity > 0) {
        // Check if the product is a variable product
        if ($product->is_type('variable')) {
            if ($variation && $quantity > 0) {
                $variation_price = $variation->get_price();
                $variation_data = array('variation_id' => $variation_id,);
                for ($gst = 0;$gst < $quantity;$gst++) {
                    $order->add_product($variation, $variation_data);
                }
            }
        } else {
            $order->add_product($product, $quantity);
        }
    }
}


// Calculate totals and save the order
$order->calculate_totals();

if ($order->save()) {
    
    global $wpdb;
    $wpdb->query("DELETE FROM `wpuo_custom_cart` WHERE `cart_user_id` = '$user_id'");
    $response['success'] = 1;
    $response['total'] = $order->get_total();

    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    $response['success'] = 0;
    $response['error'] = 'Failed to save the order.';

    header('Content-Type: application/json');
    echo json_encode($response);
}



?>







<?php
