<?php

//https://technorizen.com/_angotech_homol1/wp-webservices/wish-list-test.php?user_id=3

require_once('../wp-config.php'); // replace with your WordPress installation path
global $wpdb;

function generate_wishlist_token() {
    global $wpdb;

    do {
        $dictionary = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $nchars = 12;
        $token = "";

        for ($i = 0; $i < $nchars; $i++) {
            $token .= $dictionary[mt_rand(0, strlen($dictionary) - 1)];
        }

        $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->yith_wcwl_wishlists} WHERE wishlist_token = %s", $token));
    } while ($count != 0);

    return $token;
}

function create_wishlist($user_id) {
    global $wpdb;

    $token = generate_wishlist_token(); // Generate a unique wishlist token

    // Insert a new record into the wishlist table
    $wpdb->insert($wpdb->yith_wcwl_wishlists, array(
        'user_id' => $user_id,
        'wishlist_slug' => '',
        'wishlist_token' => $token,
        'wishlist_name' => '',
        'wishlist_privacy' => 0,
        'is_default' => 0,
        'session_id' => '',
        'expiration'=> '0000-00-00 00:00:00',
        
        
    ));

    $wishlist_id = $wpdb->insert_id; // Get the ID of the created wishlist

    if ($wishlist_id) {
        return $wishlist_id;
    } else {
        return false; // Failed to create wishlist
    }
}

$user_id = $_REQUEST['user_id']; // Replace with the desired user ID
$wishlist_id = create_wishlist($user_id);

if ($wishlist_id) {
    echo "Wishlist created successfully. Wishlist ID: $wishlist_id";
} else {
    echo "Failed to create wishlist.";
}
?>