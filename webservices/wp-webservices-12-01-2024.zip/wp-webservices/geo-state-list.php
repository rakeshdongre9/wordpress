<?php

//https://technorizen.com/_angotech_homol1/wp-webservices/geo-state-list.php?country_code=IN


require_once('../wp-config.php'); // replace with your WordPress installation path

// Check if a country code is provided in the request
if (isset($_GET['country_code'])) {
    $country_code = $_GET['country_code'];

    // Retrieve the state list for the specified country
    $states = WC()->countries->get_states($country_code);



$state = array();


foreach($states as $key => $states_in){
    
    $state[] = array("code"=>$key,"name"=>$states_in);
}


    $response = array(
        'states' => $state 
        
        ,
        'message' => 'State list retrieved successfully',
        'status' => '1'
    );

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array(
        'message' => 'Country code not provided',
        'status' => '0'
    );

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}
?>