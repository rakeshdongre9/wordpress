<?php



require_once "../wp-config.php";

//https://technorizen.com/_angotech_homol1/wp-webservices/like-product-like-unlike.php?product_id=8181&user_id=1

require_once "../wp-config.php";

$product_id = $_REQUEST['product_id'];
$user_id = $_REQUEST['user_id'];

$date_time = date('Y:m:d H:i:s');

// Check if the record already exists
$existing_record = $wpdb->get_row("SELECT * FROM `wpuo_like` WHERE `product_id` = '$product_id' AND `user_id` = '$user_id'");

if ($existing_record) {
    // Remove the existing record
    $delete_sql = "DELETE FROM `wpuo_like` WHERE `product_id` = '$product_id' AND `user_id` = '$user_id';";
    $result = $wpdb->query($delete_sql);

    if ($result !== false) {
        $msg["result"] = "1";
        $msg["message"] = "Record removed successfully";
        $msg["status"] = "1";
    } else {
        $msg["result"] = [];
        $msg["message"] = "Error removing the record";
        $msg["status"] = "0";
    }
} else {
    // Insert a new record
    $insert_sql = "INSERT INTO `wpuo_like` (`product_id`, `user_id`) VALUES ('$product_id', '$user_id');";
    $result = $wpdb->query($insert_sql);

    if ($result !== false) {
        $msg["result"] = "1";
        $msg["message"] = "Record inserted successfully";
        $msg["status"] = "1";
    } else {
        $msg["result"] = [];
        $msg["message"] = "Error inserting the record";
        $msg["status"] = "0";
    }
}

header("Content-type: application/json");
echo json_encode($msg);

?>