<?php 
//https://suuqonline.com/wp-webservices/get_banner_2.php

            require_once('../wp-config.php');

            
          
    global $wpdb;
    $query = "SELECT *  FROM wp_add_banner_2 WHERE banner_type = 'BANNER'";
    $results = $wpdb->get_results($query,ARRAY_A);

    if ($results) {
        $i=0;
        foreach($results as $resultsin){
            
            $results[$i]['banner_image'] =  home_url() . "/wp-uploads/images/banners/"  .$resultsin['banner_image'];
            $i++;
        }
        $msg['result'] = $results;
        $msg["message"] = "success";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg); 
    } else {
        $msg['result'] = "Data Not found";
        $msg["message"] = "No Data Found";
        $msg["status"] = "0";
        header('Content-type:application/json');
        echo json_encode($msg);
    }

?>