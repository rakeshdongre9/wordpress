<?php 

require_once('../wp-config.php');


$user_id = $_REQUEST['user_id']; 
$otp = $_REQUEST['otp'];

  $check_login = $wpdb->get_results( "SELECT  *  FROM  `wpuo_users`  WHERE  `ID`  =  '$user_id' ");
  
 
 if($check_login)
    
    {
   $checkotp = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_value` = '$otp' ");
    if($checkotp)
    {
        $msg['result'] = $check_login[0];
        $msg["message"] = "success";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg); 
        
    }
    else
    {
        $msg['result'] = "Otp Not Match ...";
        $msg["message"] = "success";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg); 
    }
    
       
    }
    else
    {
         $msg['result'] = "User Id Not Found";
        $msg["message"] = "No Data Found";
        $msg["status"] = "0";
        header('Content-type:application/json');
        echo json_encode($msg);
    }


?>