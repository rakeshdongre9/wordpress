<?php

require_once "../wp-config.php";

//https://technorizen.com/_angotech_homol1/wp-webservices/chat-get-by-id.php?chat_id=2

$chat_id = $_REQUEST['chat_id'];

$sql = "SELECT * FROM `dNvuK_chat` WHERE `chat_id`='$chat_id';";
$check_events = $wpdb->get_row($sql);
    
if ($check_events) {
    $msg["result"] = $check_events;
    $msg["message"] = "successful";
    $msg["status"] = "1";
    header("Content-type:application/json");
    echo json_encode($msg);
    die();
} else {
    $msg["result"] = [];
    $msg["message"] = "unsuccessful";
    $msg["status"] = "0";
    header("Content-type:application/json");
    echo json_encode($msg);
}

?>