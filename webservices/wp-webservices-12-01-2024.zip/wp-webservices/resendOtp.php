<?php 

require_once('../wp-config.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;


require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php'; 

// Create an instance of PHPMailer class 
$mail = new PHPMailer;

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);



$user_id = $_REQUEST['user_id']; 

  $check_login = $wpdb->get_results( "SELECT  *  FROM  `wpuo_users`  WHERE  `ID`  =  '$user_id' ");
  
  $login_user_array1 = json_decode(json_encode($check_login), true);
  $user_email = $login_user_array1[0]['user_email'];
  $user_login = $login_user_array1[0]['user_login'];

  
 
 if($check_login)
    
    {

     // user ke mobile no pr otp send krna he
     $otp = '1234';
   $checkdata = $wpdb->get_results( "SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'signupotp' ");
   $login_user_array = json_decode(json_encode($checkdata), true);
   $id = $login_user_array[0]['umeta_id'];

   if($checkdata)
   {
       
        $wpdb->get_results( "UPDATE `wpuo_usermeta` SET `meta_value`= '$otp' WHERE `user_id` = '$user_id' AND `umeta_id` = '$id' ");
        
        
        
        $to = $user_email;
        $subject = "VERIFYCATION OTP";

        $content = "<div style='max-width: 600px; width: 100%; margin-left: auto; margin-right: auto;'>
            <header style='color: #fff; width: 100%;'>
            
           </header>
        
           <div style='margin-top: 10px; padding-right: 10px; 
           padding-left: 125px;
           padding-bottom: 20px;'>
           <hr>
        
           <p>Name :  $user_login</p>
        
           <p>Email : $user_email</p>
        
           <p>Your Otp is : $otp</p>
           <hr>

   <p>Warm Regards<br> Ebx Ecommerce <br>Support Team</p>

 </div>
</div>

</div>";

    
     //Server settings
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;    //Enable verbose debug output
    //$mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'justtest@technorizen.com';                     //SMTP username
    $mail->Password   = 'justtest@123';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setfrom('amir@technorizen.com', 'Mailer');
    $mail->addaddress($user_email, 'rakesh dongre');     //Add a recipient



    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $content;
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
        
        
        
        
        $msg['result'] = 'Otp Send Successfully...';
        $msg["message"] = "success";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg); 

       
   }
   else
   {
        $msg['result'] = "Unsuccess";
        $msg["message"] = "No Data Found";
        $msg["status"] = "0";
        header('Content-type:application/json');
        echo json_encode($msg);
   }
   
   // SELECT * FROM `dNvuK_usermeta` WHERE `umeta_id` = '320' AND `user_id` = 21 AND `meta_key` = 'otp'
   
   
    
       
    }
    
    else
    {
         $msg['result'] = "User Id Not Found";
        $msg["message"] = "No Data Found";
        $msg["status"] = "0";
        header('Content-type:application/json');
        echo json_encode($msg);
    }





?>