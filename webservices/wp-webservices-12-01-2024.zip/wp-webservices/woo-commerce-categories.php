<?php

require_once('../wp-config.php'); // replace with your WordPress installation path

//https://technorizen.com/_angotech_homol1/wp-webservices/woo-commerce-categories.php



function get_category_tree($parent_id = 0) {
    $args = array(
        'parent' => $parent_id,
        'hide_empty' => false,
        'taxonomy' => 'product_cat',
    );
    
    $categories = get_terms($args);
    
    $result = array();
    
    foreach($categories as $category) {
        $data = array(
            'id' => $category->term_id,
            'name' => $category->name,
            'slug' => $category->slug,
            'image' => '',
            'children' => array()
        );
        
        // Get the category image URL
        $image_id = get_term_meta($category->term_id, 'thumbnail_id', true);
        if ($image_id) {
            $image_url = wp_get_attachment_image_src($image_id, 'full');
            $data['image'] = $image_url[0];
        }
        
        $children = get_category_tree($category->term_id);
        
        if(!empty($children)) {
            $data['children'] = $children;
        }
        
        $result[] = $data;
    }
    
    return $result;
}

// Call the function to get the top-level categories
$categories = get_category_tree();

// Output the result as JSON
header('Content-Type: application/json');
echo json_encode($categories);