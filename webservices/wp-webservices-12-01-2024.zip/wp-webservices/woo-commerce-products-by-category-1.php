<?php

require_once('../wp-config.php'); // replace with your WordPress installation path

function replace_null_with_empty_string(&$array) {
    foreach ($array as &$value) {
        if (is_array($value)) {
            replace_null_with_empty_string($value);
        } else if ($value === null) {
            $value = '';
        }
    }
}


/*
function get_products_by_category($category_id, $image_not_available) {
    $category = get_term_by('id', $category_id, 'product_cat');

    if (!$category) {
        return array(
            'error' => true,
            'message' => 'Category not found',
        );
    }

    $data = array(
        'id' => $category->term_id,
        'name' => $category->name,
        'slug' => $category->slug,
        'image' => '',
        'products' => array()
    );

    // Get the category image URL
    $image_id = get_term_meta($category->term_id, 'thumbnail_id', true);

    if ($image_id) {
        $image_url = wp_get_attachment_image_src($image_id, 'full');
        $data['image'] = $image_url[0];
    }

    // Get products in the specified category
    $product_args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $category_id,
            ),
        ),
        'post_status' => 'publish', // Filter by published status
    );

    $products = new WP_Query($product_args);

    if ($products->have_posts()) {
        while ($products->have_posts()) {
            $products->the_post();
            $product_id = get_the_ID();

            $product = wc_get_product($product_id);

            $product_data = array(
                'id' => $product_id,
                'name' => get_the_title(),
                'permalink' => get_permalink(),
                'images' => array(),
                'meta' => array(),
                'price' => $product->get_price(),
                'regular_price' => $product->get_regular_price(),
                'sale_price' => $product->get_sale_price(),
                'description' => get_the_content(),
                'attributes' => $product->get_attributes(),
            );

            $product_images = $product->get_gallery_image_ids();

            foreach ($product_images as $image_id) {
                $image_url = wp_get_attachment_image_src($image_id, 'full');
                if ($image_url) {
                    $product_data['images'][] = $image_url[0];
                }
            }

            $image_id = $product->image_id;
            $image_status = wp_get_attachment_image_url($image_id, 'full');
            $product_data['main_image'] = ($image_status != NULL) ? wp_get_attachment_image_url($image_id, 'full') : $image_not_available;

            // Get additional metadata
            $product_meta = get_post_meta($product_id);
            foreach ($product_meta as $meta_key => $meta_value) {
                $product_data['meta'][$meta_key] = $meta_value[0];
            }

            $data['products'][] = $product_data;
        }
    }

    wp_reset_postdata();

    return $data;
}
*/


function get_products_by_category($category_id, $image_not_available) {
    $category = get_term_by('id', $category_id, 'product_cat');

    if (!$category) {
        return array(
            'error' => true,
            'message' => 'Category not found',
        );
    }

    $data = array(
        'id' => $category->term_id,
        'name' => $category->name,
        'slug' => $category->slug,
        'image' => '',
        'products' => array()
    );

    // Get the category image URL
    $image_id = get_term_meta($category->term_id, 'thumbnail_id', true);

    if ($image_id) {
        $image_url = wp_get_attachment_image_src($image_id, 'full');
        $data['image'] = $image_url[0];
    }

    // Get products in the specified category
    $product_args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $category_id,
            ),
        ),
        'post_status' => 'publish', // Filter by published status
    );

    $products = new WP_Query($product_args);

    if ($products->have_posts()) {
        while ($products->have_posts()) {
            
            $unique = array();
            
            $products->the_post();
            $product_id = get_the_ID();

            $product = wc_get_product($product_id);

            $product_data = array(
                'id' => $product_id,
                'name' => get_the_title(),
                'permalink' => get_permalink(),
                'images' => array(),
                'meta' => array(),
                'price' => $product->get_price(),
                'regular_price' => $product->get_regular_price(),
                'sale_price' => $product->get_sale_price(),
                'description' => get_the_content(),
                'attributes' => $product->get_attributes(),
                'variations' => array(),
            );

            $product_images = $product->get_gallery_image_ids();

            foreach ($product_images as $image_id) {
                $image_url = wp_get_attachment_image_src($image_id, 'full');
                if ($image_url) {
                    $product_data['images'][] = $image_url[0];
                }
            }

            $image_id = $product->image_id;
            $image_status = wp_get_attachment_image_url($image_id, 'full');
            $product_data['main_image'] = ($image_status != NULL) ? wp_get_attachment_image_url($image_id, 'full') : $image_not_available;

            // Get additional metadata
            $product_meta = get_post_meta($product_id);
            foreach ($product_meta as $meta_key => $meta_value) {
                $product_data['meta'][$meta_key] = $meta_value[0];
            }

            // Get variations for the product
            if ($product->is_type('variable')) {
                $variation_ids = $product->get_children();

                foreach ($variation_ids as $variation_id) {
                    $variation = wc_get_product($variation_id);
                    
                    
    $original_color_name = $variation->get_attribute('pa_color');

            $variation_image_id = $variation->get_image_id();

            $variation_image_url = ($variation_image_id != 0) ? wp_get_attachment_image_url($variation_image_id, 'full') : $image_not_available;




                     $new_array  = $variation->get_attributes();
                     
                     
             if (isset($new_array['pa_color'])) {
                 
                 $attribute_taxonomy = 'pa_color';
                  $term_slug = $new_array['pa_color'];
                  
    $term = get_term_by('slug', $term_slug, $attribute_taxonomy);
    




    
       $color_code = get_term_meta($term->term_id, 'product_attribute_color', true);
  
             }
             
             if($color_code == ""){
                 $color_code = "#ankita";
             }

            
                     
                     
                    $variation_data = array(
                        'id' => $variation_id,
                        'name' => $variation->get_name(),
                        'price' => $variation->get_price(),
                        'regular_price' => $variation->get_regular_price(),
                        'sale_price' => $variation->get_sale_price(),
                        'attributes' => $variation->get_attributes(),
                        
                       'image' => $variation_image_url,

                'original_color_name'  =>   $original_color_name ,
                
                'color_code'  =>  @$color_code,
                
                    );
                    
                    
                    
            //   echo "<pre>";
            // print_r($new_array);
            // echo "</pre>";
            
            // echo $new_array['pa_color'];
            
           // pa_color
           
                 $unique[][$new_array['pa_color']] = array(  
                     

                     'color_origin'  =>  $original_color_name, 
                     'color_name'  =>  $new_array['pa_color'], 
                     'color_code'  =>  @$color_code, 
                     'color_size' => $new_array['pa_size'],
                     'color_image' => $variation_image_url

                     
                     ) ;
                     
                     
                     
                     
                    

            
            
                    $product_data['variations'][] = $variation_data;
                }
                

                
            }
            


                          $uniqueElements = array();


             foreach ($unique as $item) {
    foreach ($item as $key => $value) {
            $uniqueElements[$key][] = $value;
        
    }
}


            $uniqueElements = array_values($uniqueElements);
            
            $product_data['variation_data'] = $uniqueElements;






global $wpdb;

// Check if the record already exists

 $d = "SELECT * FROM `wpuo_like` WHERE `product_id` = '$product_id' AND `user_id` = '".$_REQUEST['user_id']."'";

$existing_record = $wpdb->get_row($d);

if ($wpdb->num_rows>0) {
           $product_data['like_status'] =  true;
} else {
           $product_data['like_status'] =  false;

}









            $data['products'][] = $product_data;
            
            
            
        }
        
        
        
    }

    wp_reset_postdata();

    return $data;
}


// Check if a category ID is provided in the request
if (isset($_GET['category_id'])) {
    $category_id = $_GET['category_id'];

    // Get products for the specified category ID
    $products = get_products_by_category($category_id,$image_not_available);


    replace_null_with_empty_string($products);


      if(@$products['error'] == true ){ 

    // Output the result as JSON
    header('Content-Type: application/json');
    
    $result['result'] = [];
    $result['message'] = "unsuccess"; 
    $result['status'] =  "0";
    
      }else{
    // Output the result as JSON
    header('Content-Type: application/json');
    $result['result'] = $products;
    $result['message'] = "List Success"; 
    $result['status'] =  "1";
    
      }

    echo json_encode($result);
    
    
    
    die;
} else {

    // Output the result as JSON
    header('Content-Type: application/json');
    
    $result['result'] = [];
    $result['message'] = "unsuccess"; 
    $result['status'] =  "0";

    echo json_encode($result);
    
    die;
}