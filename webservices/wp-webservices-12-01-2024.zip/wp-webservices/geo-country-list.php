<?php

//https://technorizen.com/_angotech_homol1/wp-webservices/geo-country-list.php

require_once('../wp-config.php'); // replace with your WordPress installation path

// Retrieve the country list
$countries = WC()->countries->get_countries();

$country = array();

foreach($countries as $key => $countries_in){
    
    $country[] = array("code"=>$key,"name"=>$countries_in);
}


$response = array(
    'countries' => $country,
    'message' => 'Country list retrieved successfully',
    'status' => '1'
);

// Output the result as JSON
header('Content-Type: application/json');
echo json_encode($response);
die;
?>