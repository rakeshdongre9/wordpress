<?php

require_once('../wp-config.php'); // replace with your WordPress installation path

//https://technorizen.com/_angotech_homol1/wp-webservices/woo-commerce-categories-for-app.php

// Set CORS headers to allow requests from different origins
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

function get_category_with_children($category_id) {
    $category = get_term($category_id, 'product_cat');

    $data = array(
        'id' => $category->term_id,
        'name' => $category->name,
        'slug' => $category->slug,
        'image' => '',
        'children' => array()
    );

    // Get the category image URL
    $image_id = get_term_meta($category->term_id, 'thumbnail_id', true);
    if ($image_id) {
        $image_url = wp_get_attachment_image_src($image_id, 'full');
        $data['image'] = $image_url[0];
    }

    // Get and include children categories
    $child_categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'parent' => $category_id,
    ));

    foreach ($child_categories as $child_category) {
        $child_data = get_category_with_children($child_category->term_id);
        $data['children'][] = $child_data;
    }

    return $data;
}

try {
    
    
     global $wpdb;
    $category_ids = $wpdb->get_var("SELECT `category` FROM `{$wpdb->prefix}app_main_category` WHERE 1");

    if ($category_ids) {
        $category_ids_array = explode(',', $category_ids);
        
        $categories = array();
        
        foreach ($category_ids_array as $category_id) {
            $categories[] = get_category_with_children($category_id);
        }

        echo json_encode($categories);

        //echo json_encode(array('result' => $categories, 'success' => 'Category', 'status' => 1));
    } else {
        http_response_code(404); // Not Found
        echo json_encode(array());
        //echo json_encode(array('result' => '', 'success' => 'Categories Not Found', 'status' => 0));
    }
    
    

} catch (Exception $e) {
    // Handle exceptions and output an error message
    http_response_code(500); // Internal Server Error
    echo json_encode(array());
    //echo json_encode(array('result' => '', 'success' => 'Error', 'status' => 0));
}