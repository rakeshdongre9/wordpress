<?php

//https://suuqonline.com/wp-webservices/cart-update-to-cart.php?product_id=8427&variation_id=8727&quantity=2&user_id=1

require_once('../wp-config.php'); // replace with your WordPress installation path
global $wpdb;


// Retrieve values from $_REQUEST
$cart_product_id = $_REQUEST['product_id'];
$cart_variation_id = $_REQUEST['variation_id'];
$cart_quantity = $_REQUEST['quantity'];
$cart_user_id = $_REQUEST['user_id'];

// Prepare the update statement
$update_query = $wpdb->prepare(
    "UPDATE wpuo_custom_cart SET cart_quantity = %s WHERE cart_product_id = %s and cart_variation_id = %s and cart_user_id = %s",
    $cart_quantity,
    $cart_product_id,
    $cart_variation_id,
    $cart_user_id
);

// Execute the update query
$result = $wpdb->query($update_query);

if ($result !== false) {
    // Update successful
    $response = array(
        'result' => $result,
        'message' => 'Data updated in the custom table',
        'status' => '1'
    );
} else {
    // Update failed
    $response = array(
        'result' => $result,
        'message' => 'Failed to update data in the custom table',
        'status' => '0'
    );
}

// Output the result as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>