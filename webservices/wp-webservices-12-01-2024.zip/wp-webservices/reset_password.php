<?php
require_once ('../wp-config.php');
$user_id = $_REQUEST['user_id'];
$password = $_REQUEST['password'];
$pass = md5($password);
$check_login = $wpdb->get_results("SELECT  *  FROM  `wp_users`  WHERE  `ID`  =  '$user_id' ");
if ($check_login) {
    $wpdb->get_results(" UPDATE `wp_users` SET `user_pass`= '$pass' WHERE `ID` = '$user_id' ");
    $msg['result'] = $check_login[0];
    $msg["message"] = "success";
    $msg["status"] = "1";
    header('Content-type:application/json');
    echo json_encode($msg);
} else {
    $msg['result'] = "User Id Not Found";
    $msg["message"] = "No Data Found";
    $msg["status"] = "0";
    header('Content-type:application/json');
    echo json_encode($msg);
}
?>