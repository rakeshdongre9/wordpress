<?php


// ///https://technorizen.com/_angotech_homol1/wp-webservices/user-shipping-address-update.php?user_id=1&shipping_first_name

// &shipping_last_name=
// &shipping_phone=
// &shipping_email=
// &shipping_address_1=
// &shipping_address_2=
// &shipping_city=
// &shipping_state=
// &shipping_postcode=
// &shipping_country=

require_once('../wp-config.php'); // replace with your WordPress installation path

// Check if a user ID is provided in the request
if (isset($_REQUEST['user_id'])) {
    $user_id = $_REQUEST['user_id'];

    // Update shipping fields
    update_user_meta($user_id, 'shipping_first_name', $_REQUEST['shipping_first_name']);
    update_user_meta($user_id, 'shipping_last_name', $_REQUEST['shipping_last_name']);
    update_user_meta($user_id, 'shipping_phone', $_REQUEST['shipping_phone']);
    update_user_meta($user_id, 'shipping_email', $_REQUEST['shipping_email']);
    update_user_meta($user_id, 'shipping_address_1', $_REQUEST['shipping_address_1']);
    update_user_meta($user_id, 'shipping_address_2', $_REQUEST['shipping_address_2']);
    update_user_meta($user_id, 'shipping_city', $_REQUEST['shipping_city']);
    update_user_meta($user_id, 'shipping_state', $_REQUEST['shipping_state']);
    update_user_meta($user_id, 'shipping_postcode', $_REQUEST['shipping_postcode']);
    update_user_meta($user_id, 'shipping_country', $_REQUEST['shipping_country']);

    $response = array(
        'message' => 'Shipping fields updated successfully',
        'status' => '1'
    );

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array(
        'message' => 'User ID not provided',
        'status' => '0'
    );

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}
?>