<?php
//https://technorizen.com/_angotech_homol1/wp-webservices/wish-list-get.php?user_id=1
require_once ('../wp-config.php'); // replace with your WordPress installation path
global $wpdb;
function get_product_by_id($product_id, $image_not_available) {
    $product = wc_get_product($product_id);
    if (!$product) {
        return array('error' => true, 'message' => 'Product not found',);
    }
    
    $product_data = array(
        'id' => $product_id, 
        'name' => $product->get_name(), 
        //'permalink' => $product->get_permalink(), 
        //'images' => array(), 'meta' => array(), 
        'price' => $product->get_price(), 
        //'image' => ($image_status != NULL) ? wp_get_attachment_image_url($image_id, 'full') : $image_not_available,
        //'regular_price' => $product->get_regular_price(), 
        //'sale_price' => $product->get_sale_price(), 
        //'description' => $product->get_description(), 
        //'attributes' => $product->get_attributes(),
        );
        
    $product_images = $product->get_gallery_image_ids();
    foreach ($product_images as $image_id) {
        $image_url = wp_get_attachment_image_src($image_id, 'full');
        if ($image_url) {
            //$product_data['images'][] = $image_url[0];
        }
    }
    $image_id = $product->get_image_id();
    $image_status = wp_get_attachment_image_url($image_id, 'full');
    
    //$product_data['main_image'] = ($image_status != NULL) ? wp_get_attachment_image_url($image_id, 'full') : $image_not_available;
    
       $product_data['image'] = ($image_status != NULL) ? wp_get_attachment_image_url($image_id, 'full') : $image_not_available;

    
    // Get additional metadata
    $product_meta = get_post_meta($product_id);
    foreach ($product_meta as $meta_key => $meta_value) {
        //$product_data['meta'][$meta_key] = $meta_value[0];
        
    }
    return $product_data;
}
// Check if a user ID is provided in the request
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    // Retrieve the wishlist items from the YITH Wishlist table
    $table_name = 'wp_yith_wcwl';
    $wishlist_items = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d", $user_id));
    if (empty($wishlist_items)) {
        $response = array('wishlist' => array(), 'message' => 'Wishlist is empty', 'status' => '1');
    } else {
        $wishlist = array();
        $image_not_available = 'https://example.com/image-not-available.jpg'; // Replace with your image URL for when the image is not available
        foreach ($wishlist_items as $item) {
            $product_id = $item->prod_id;
            $product = get_product_by_id($product_id, $image_not_available);
            if (@$product['error'] == true) {
            } else {
                //$product['user_id'] = $item->user_id;
                //$product['wishlist_id'] = $item->wishlist_id;
                $product['wish_status'] = true;

                $wishlist[] = $product;
            }
            $response = array('wishlist' => $wishlist, 'message' => 'Wishlist retrieved successfully', 'status' => '1');
        }
    }
    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array('wishlist' => array(), 'message' => 'User ID not provided', 'status' => '0');
    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}
?>