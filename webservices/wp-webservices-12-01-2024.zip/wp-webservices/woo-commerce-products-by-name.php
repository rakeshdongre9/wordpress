<?php
require_once ('../wp-config.php'); // replace with your WordPress installation path
// https://suuqonline.com/wp-webservices/woo-commerce-products-by-name.php?product_name=Product%20Name&user_id=1
function get_products_by_name($product_name, $image_not_available) {
    $user_id = $_REQUEST['user_id'];
    // Perform a custom query to search for products by name
    global $wpdb;
    $product_query = "
        SELECT p.ID 
        FROM {$wpdb->posts} p
        WHERE p.post_type = 'product'
        AND p.post_status = 'publish'
        AND p.post_title LIKE '%$product_name%'
    ";
    $product_ids = $wpdb->get_col($product_query);
    if (empty($product_ids)) {
        return array('error' => true, 'message' => 'Products not found',);
    }
    $products_data = array();
    foreach ($product_ids as $product_id) {
        $product = wc_get_product($product_id);
        if ($product) {
            // Get the product image ID
            $image_id = $product->get_image_id();
            if ($image_id) {
                // Get the full-size image URL using the image ID
                $image_url = wp_get_attachment_url($image_id);
            } else {
                // If no image is available, use the provided fallback image URL
                $image_url = $image_not_available;
            }
            // Format each product's data and add it to the result array
            $product_data = array('id' => $product_id, 'name' => $product->get_name(), 'image' => $image_url, // Get the product image URL
            'price' => $product->get_price(), // Get the product price
            // Add other product fields as needed
            );
            
            
            
           global $wpdb;
            // Check if the record already exists
            $d = "SELECT * FROM `wp_yith_wcwl` WHERE `prod_id` = '$product_id' AND `user_id` = '" . $_REQUEST['user_id'] . "'";
            $existing_record = $wpdb->get_row($d);
            if ($wpdb->num_rows > 0) {
                $product_data['wish_status'] = true;
            } else {
                $product_data['wish_status'] = false;
            }
            
            
            
            $products_data[] = $product_data;
        }
    }
    return $products_data;
}
// Check if a product name is provided in the request
if (isset($_GET['product_name'])) {
    $product_name = $_GET['product_name'];
    // Get products information for the specified name
    $products = get_products_by_name($product_name, $image_not_available);
    if (empty($products)) {
        $response = array('result' => [], 'message' => 'unsuccess', 'status' => '0');
    } else {
        $response = array('result' => $products, 'message' => 'Success', 'status' => '1');
    }
    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array('result' => [], 'message' => 'unsuccess', 'status' => '0');
    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}
