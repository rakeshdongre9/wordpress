<?php
   // define('WP_DEBUG',true);
   // define('WP_DEBUG_LOG',true);
   require_once "../wp-config.php";
   //https://technorizen.com/_angotech_homol1/wp-webservices/chat-get.php?my_id=2&friend_id=2
   //https://server-php-7-3.technorizen.com/_angotech_homol1/wp-webservices/chat-get.php?my_id=2&friend_id=2
   
   $my_id = $_REQUEST['my_id'];
   $friend_id = $_REQUEST['friend_id'];
   
   
   
   /************************************************/
   
    $get_user_meta = get_user_meta($my_id);
    $get_other_user_meta = get_user_meta($friend_id);

     // echo $get_user_meta['image'][0];
    
    
         $get_user_meta_image =  ( $get_user_meta['image'][0] == "") ? "" : home_url() . "wp-uploads/user/" . $get_user_meta['image'][0] ;


         $get_other_user_meta_image =  ( $get_other_user_meta['image'][0] == "") ? "" : home_url() . "wp-uploads/user/" . $get_other_user_meta['image'][0] ;
        

   /************************************************/
   
   
   
   $sql = "SELECT * FROM `dNvuK_chat` WHERE  ((`chat_receiver_id` = '$my_id' and  `chat_sender_id` = '$friend_id') or 
   (`chat_sender_id` = '$my_id' and  `chat_receiver_id` = '$friend_id'));";
   $check_events = $wpdb->get_results($sql, ARRAY_A);
   if ($check_events) {
       $d = 0;
       foreach ($check_events as $check_events_in) {
           $sql = "UPDATE `dNvuK_chat` SET  `chat_seen_status`='SEEN' WHERE `chat_id`='" . $check_events_in['chat_id'] . "' and `chat_receiver_id` = '$my_id'";
           $wpdb->query($sql);
           if ($my_id == $check_events_in['chat_receiver_id']) {
               $check_events[$d]['chat_who_sent'] = "RECEIVED";
               $user_id = $check_events_in['chat_receiver_id'];
               $sql = "SELECT * FROM `dNvuK_users` where `ID`='$user_id' ORDER BY ID DESC LIMIT 1 ";
               $check_login = $wpdb->get_row($sql, ARRAY_A);
               $get_user_meta = get_user_meta($user_id);
           } else {
               $check_events[$d]['chat_who_sent'] = "SENT";
               $user_id = $check_events_in['chat_sender_id'];
               $sql = "SELECT * FROM `dNvuK_users` where `ID`='" . $check_events_in['chat_receiver_id'] . "' ORDER BY ID DESC LIMIT 1 ";
               $check_login = $wpdb->get_row($sql, ARRAY_A);
               $get_user_meta = get_user_meta($check_events_in['chat_receiver_id']);
           }
           if ($check_events_in['chat_type'] == "IMAGE") {
               //echo $check_events_in['chat_type'];
               $resulx = $wpdb->get_results("SELECT * FROM `dNvuK_chat_files` WHERE `chat_files_id` ='" . $check_events_in['chat_post_id'] . "'", ARRAY_A);
               if ($wpdb->num_rows > 0) {
                   $p = 0;
                   foreach ($resulx as $resulx_in) {
                       $resulx[$p]['chat_files_name'] = home_url() . "/wp-uploads/chat/" . $resulx_in['chat_files_name'];
                       $p++;
                   }
                   $check_events[$d]['image_data'] = $resulx;
               } else {
                   $check_events[$d]['image_data'] = array();
               }
           }
           if ($check_events_in['chat_type'] == "VIDEO") {
               //echo $check_events_in['chat_type'];
               $resulx = $wpdb->get_results("SELECT * FROM `dNvuK_chat_files` WHERE `chat_files_id` ='" . $check_events_in['chat_post_id'] . "'", ARRAY_A);
               if ($wpdb->num_rows > 0) {
                   $p = 0;
                   foreach ($resulx as $resulx_in) {
                       $resulx[$p]['chat_files_name'] = home_url() . "/wp-uploads/chat/" . $resulx_in['chat_files_name'];
                       $p++;
                   }
                   $check_events[$d]['video_data'] = $resulx;
               } else {
                   $check_events[$d]['video_data'] = array();
               }
           }
           if ($check_events_in['chat_type'] == "POST") {
               //echo $check_events_in['chat_type'];
               $resulx = $wpdb->get_results("SELECT * FROM `dNvuK_news_feed` WHERE `news_feed_id` ='" . $check_events_in['chat_post_id'] . "'", ARRAY_A);
               if ($wpdb->num_rows > 0) {
                   $p = 0;
                   foreach ($resulx as $resulx_in) {
                       $resulx[$p]['news_feed_comment'] = rand(1111, 9999);
                       $resulx[$p]['news_feed_like'] = rand(1111, 9999);
                       $resulx[$p]['news_feed_image'] = home_url() . "/xcrud/photos/" . $resulx_in['news_feed_image'];
                       $p++;
                   }
                   $check_events[$d]['news_feed_data'] = $resulx;
               } else {
                   $check_events[$d]['news_feed_data'] = array();
               }
           }
           if ($check_events_in['chat_type'] == "PRODUCT") {
               $product_query = "SELECT * FROM `dNvuK_products` WHERE `prod_id`='" . $check_events_in['chat_post_id'] . "'";
               $product_results = $wpdb->get_results($product_query);
               if ($product_results) {
                   $products = [];
                   // Iterate through each product
                   foreach ($product_results as $product_result) {
                       $product = ['prod_id' => $product_result->prod_id, 'prod_owner_id' => $product_result->prod_owner_id, 'prod_name' => $product_result->prod_name, 'prod_price' => $product_result->prod_price, 'prod_description' => $product_result->prod_description, 'prod_status' => $product_result->prod_status, 'images' => [], 'review' => array(), 'review_count' => rand(11, 99), 'review_average_rating' => 5, ];
                       // Retrieve images for each product
                       $prod_id = $product_result->prod_id;
                       $image_query = "SELECT `prod_img_id`, `prod_img_name`, `prod_id_original` FROM `dNvuK_products_image` WHERE `prod_id_original` = '$prod_id'";
                       $image_results = $wpdb->get_results($image_query);
                       // Iterate through each image
                       foreach ($image_results as $image_result) {
                           $image = ['prod_img_id' => $image_result->prod_img_id, 'prod_img_name' => home_url() . "/wp-uploads/product/" . $image_result->prod_img_name, 'prod_id_original' => $image_result->prod_id_original];
                           $product['images'][] = $image;
                       }
                       $products[] = $product;
                   }
                   $check_events[$d]['product_data'] = $product;
               }
           }
           $check_events[$d]['chat_username'] = $check_login['user_nicename'];
           $check_events[$d]['chat_image'] = ($get_user_meta['image'][0] != NULL) ? $get_user_meta['image'][0] : "";
           $d++;
       }
       function removeNullValues($array) {
           foreach ($array as & $value) {
               if (is_array($value)) {
                   $value = removeNullValues($value);
               }
           }
           return array_filter($array, function ($element) {
               return $element !== null;
           });
       }
       $array = ['key1' => 'value1', 'key2' => null, 'key3' => 'value3', 'key4' => null, 'key5' => ['nested_key1' => 'nested_value1', 'nested_key2' => null, 'nested_key3' => 'nested_value3', 'nested_key4' => null], 'key6' => null];
       
       $msg["result"] = removeNullValues($check_events);
       
       $msg["user_image"] = $get_user_meta_image;
       $msg["other_user_image"] = $get_other_user_meta_image;

       $msg["message"] = "successful";
       $msg["status"] = "1";
       header("Content-type:application/json");
       echo json_encode($msg);
       die();
   } else {
       $msg["result"] = [];
       
       $msg["user_image"] = $get_user_meta_image;
       $msg["other_user_image"] = $get_other_user_meta_image;
       
       $msg["message"] = "unsuccessful";
       $msg["status"] = "0";
       header("Content-type:application/json");
       echo json_encode($msg);
   }
   ?>