<?php 

require_once('../wp-config.php');


$user_id = $_REQUEST['user_id']; 

  $check_login = $wpdb->get_results( "SELECT  *  FROM  `wpuo_users`  WHERE  `ID`  =  '$user_id' ");
  $check_loginDATA = json_decode(json_encode($check_login), true);
  
  $name = $check_loginDATA[0]['user_login'];
  $user_email = $check_loginDATA[0]['user_email'];
 
 if($check_login)
    
    {
   $user_imageC = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'user_image'  ");
   $user_imageC1 = json_decode(json_encode($user_imageC), true);
   $uimage = $user_imageC1[0]['meta_value'];
   
   $dob = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'dob'  ");
   $dobc = json_decode(json_encode($dob), true);
   $userDOB = $dobc[0]['meta_value'];
   
    $mobileC = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'mobile'  ");
   $mobileCA = json_decode(json_encode($mobileC), true);
   $mobile = $mobileCA[0]['meta_value'];
  
   
          $val1['username'] = $name;
          $val1['user_email'] = $user_email;
          $val1['mobile'] = $mobile;
          $val1['dob'] = $userDOB;
          $val1['image'] = site_url().'/wp-content/uploads/images/'.$uimage;
          $li[] = $val1;
        
   
//   $meta_key = $user_imageC1[0]['meta_key'];
//   if($meta_key == 'user_image')
//     {
//         echo 'image he';die;
//     }
  
//   $user_id = $login_user_array1[0]['ID'];
//   $name = $login_user_array1[0]['user_login'];

    if($user_imageC1)
    {
        $msg['result'] = $li[0];
        $msg["message"] = "success";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg); 
        
    }
    else
    {
        $msg['result'] = "Data Not found";
        $msg["message"] = "success";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg); 
    }
    
       
    }
    else
    {
         $msg['result'] = "User Id Not Found";
        $msg["message"] = "No Data Found";
        $msg["status"] = "0";
        header('Content-type:application/json');
        echo json_encode($msg);
    }


?>