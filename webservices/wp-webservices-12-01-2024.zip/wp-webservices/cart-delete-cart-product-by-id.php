<?php
// https://technorizen.com/_angotech_homol1/wp-webservices/cart-delete-cart-product-by-id.php?product_id=&user_id=1

require_once('../wp-config.php'); // replace with your WordPress installation path

global $wpdb;

$cart_product_id = $_REQUEST['product_id']; // Replace with the desired product ID
$cart_user_id = $_REQUEST['user_id']; // Replace with the desired user ID

// Prepare the delete statement
$delete_query = $wpdb->prepare(
    "DELETE FROM wpuo_custom_cart WHERE cart_product_id = %s AND cart_user_id = %s",
    $cart_product_id,
    $cart_user_id
);

// Execute the delete query
$result = $wpdb->query($delete_query);

if ($result !== false) {
    // Deletion successful
    $response = array(
        'result' => $result,
        'message' => 'Cart product deleted successfully',
        'status' => '1'
    );
} else {
    // Deletion failed
    $response = array(
        'result' => $result,
        'message' => 'Failed to delete cart product',
        'status' => '0'
    );
}

// Output the result as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>