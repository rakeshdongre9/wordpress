<?php 

require_once('../wp-config.php');


$user_id = $_REQUEST['user_id']; 


  $check_login = $wpdb->get_results( "SELECT  *  FROM  `wpuo_users`  WHERE  `ID`  =  '$user_id' ");
  $check_loginDATA = json_decode(json_encode($check_login), true);
 
 if($check_login)
    
    {
   $getsfn1 = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'shipping_first_name'  ");
   $getfname1 = json_decode(json_encode($getsfn1), true);
   $firstname = $getfname1[0]['meta_value'];
   
   $getsfn2 = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'shipping_last_name'  ");
   $getfname2 = json_decode(json_encode($getsfn2), true);
   $lname = $getfname2[0]['meta_value'];
   
   $getsfn3 = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'shipping_address_1'  ");
   $getfname3 = json_decode(json_encode($getsfn3), true);
   $address1 = $getfname3[0]['meta_value'];
   
   
   $getsfn4 = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'shipping_address_2'  ");
   $getfname4 = json_decode(json_encode($getsfn4), true);
   $address2 = $getfname4[0]['meta_value'];
   
   
   $getsfn5 = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'shipping_country'  ");
   $getfname5 = json_decode(json_encode($getsfn5), true);
   $country1 = $getfname5[0]['meta_value'];
   
   $getsfn6 = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'shipping_state'  ");
   $getfname6 = json_decode(json_encode($getsfn6), true);
   $state1 = $getfname6[0]['meta_value'];
   
   $getsfn7 = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'shipping_city'  ");
   $getfname7 = json_decode(json_encode($getsfn7), true);
   $city1 = $getfname7[0]['meta_value'];
   
   $getsfn8 = $wpdb->get_results( " SELECT * FROM `wpuo_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'shipping_phone'  ");
   $getfname8 = json_decode(json_encode($getsfn8), true);
   $phone = $getfname8[0]['meta_value'];
   
   
   
   
  
   
          $val1['first_name'] = $firstname;
          $val1['last_name'] = $lname;
          $val1['address1'] = $address1;
          $val1['address2'] = $address2;
          $val1['country'] = $country1;
          $val1['state'] = $state1;
          $val1['city'] = $city1;
          $val1['phone'] = $phone;
         
          $li[] = $val1;
        
   
//   $meta_key = $user_imageC1[0]['meta_key'];
//   if($meta_key == 'user_image')
//     {
//         echo 'image he';die;
//     }
  
//   $user_id = $login_user_array1[0]['ID'];
//   $name = $login_user_array1[0]['user_login'];

    if($check_login)
    {
        $msg['result'] = $li[0];
        $msg["message"] = "success";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg); 
        
    }
    else
    {
        $msg['result'] = "Data Not found";
        $msg["message"] = "success";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg); 
    }
    
       
    }
    else
    {
         $msg['result'] = "User Id Not Found";
        $msg["message"] = "No Data Found";
        $msg["status"] = "0";
        header('Content-type:application/json');
        echo json_encode($msg);
    }


?>