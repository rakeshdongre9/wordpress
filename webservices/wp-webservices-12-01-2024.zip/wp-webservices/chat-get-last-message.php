<?php

require_once "../wp-config.php";

$my_id = $_REQUEST['chat_receiver_id'];
$friend_id = $_REQUEST['chat_sender_id'];

// Get the last message with user names and user images
$last_message_sql = $wpdb->prepare(
    "SELECT c.*, 
            u1.meta_value AS sender_first_name, 
            u2.meta_value AS sender_last_name,
            u3.meta_value AS receiver_first_name,
            u4.meta_value AS receiver_last_name,
            COALESCE(u5.meta_value, NULL) AS sender_image_url,
            COALESCE(u6.meta_value, NULL) AS receiver_image_url
            
    FROM `dNvuK_chat` AS c
    LEFT JOIN `wpuo_usermeta` AS u1 ON c.chat_sender_id = u1.user_id AND u1.meta_key = 'first_name'
    LEFT JOIN `wpuo_usermeta` AS u2 ON c.chat_sender_id = u2.user_id AND u2.meta_key = 'last_name'
    LEFT JOIN `wpuo_usermeta` AS u3 ON c.chat_receiver_id = u3.user_id AND u3.meta_key = 'first_name'
    LEFT JOIN `wpuo_usermeta` AS u4 ON c.chat_receiver_id = u4.user_id AND u4.meta_key = 'last_name'
    LEFT JOIN `wpuo_usermeta` AS u5 ON c.chat_sender_id = u5.user_id AND u5.meta_key = 'user_image'
    LEFT JOIN `wpuo_usermeta` AS u6 ON c.chat_receiver_id = u6.user_id AND u6.meta_key = 'user_image'
    WHERE  
    (c.`chat_receiver_id` = %s AND c.`chat_sender_id` = %s) OR
    (c.`chat_sender_id` = %s AND c.`chat_receiver_id` = %s)
    ORDER BY c.`chat_id` DESC LIMIT 1;",
    $my_id,
    $friend_id,
    $my_id,
    $friend_id
);

$last_message = $wpdb->get_results($last_message_sql, ARRAY_A);

// Get unread messages (UNSEEN)
$unread_messages_sql = $wpdb->prepare(
    "SELECT * FROM `dNvuK_chat` WHERE  
    `chat_receiver_id` = %s AND `chat_sender_id` = %s AND `chat_seen_status` = 'UNSEEN';",
    $my_id,
    $friend_id
);

$unread_messages = $wpdb->get_results($unread_messages_sql, ARRAY_A);

if ($last_message) {
    // Process and format the last message here
    // You can use the existing code for processing and formatting

    // Check if the last message is the same as an unread message
    $last_message_id = $last_message[0]['chat_id'];
    $is_last_message_unread = false;
    foreach ($unread_messages as $unread_message) {
        if ($unread_message['chat_id'] == $last_message_id) {
            $is_last_message_unread = true;
            break;
        }
    }

    // Include the user image URLs, is_last_message_unread flag, and all user names in the response
    $msg["result"] = $last_message;
    $msg["result"][0]['is_last_message_unread'] = $is_last_message_unread ? '1' : '0';
    
    // Calculate the time difference
    $chat_date_time = strtotime($last_message[0]['chat_date_time']);
    $current_time = time();
    $time_difference = $current_time - $chat_date_time;

    // Convert the time difference to a human-readable format
    if ($time_difference < 60) {
        $formatted_time = "just now";
    } elseif ($time_difference < 3600) {
        $minutes = floor($time_difference / 60);
        $formatted_time = "$minutes minute(s) ago";
    } elseif ($time_difference < 86400) {
        $hours = floor($time_difference / 3600);
        $formatted_time = "$hours hour(s) ago";
    } elseif ($time_difference < 604800) {
        $days = floor($time_difference / 86400);
        $formatted_time = "$days day(s) ago";
    } else {
        $months = floor($time_difference / 2592000);
        $formatted_time = "$months month(s) ago";
    }

    $msg["result"][0]['formatted_time'] = $formatted_time;

    
    $msg["message"] = "successful";
    $msg["status"] = "1";
    header("Content-type: application/json");
    echo json_encode($msg);
    die();
} else {
    $msg["result"] = [];
    $msg["message"] = "unsuccessful";
    $msg["status"] = "0";
    header("Content-type: application/json");
    echo json_encode($msg);
}
?>


