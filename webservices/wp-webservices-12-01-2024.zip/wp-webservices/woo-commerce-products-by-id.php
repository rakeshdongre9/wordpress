<?php

require_once('../wp-config.php'); // replace with your WordPress installation path

// https://technorizen.com/_angotech_homol1/wp-webservices/woo-commerce-products-by-id.php?product_id=8533&user_id=1

function get_product_by_id($product_id, $image_not_available) {
    $user_id = $_REQUEST['user_id'];

    $product = wc_get_product($product_id);

    if (!$product) {
        return array(
            'error' => true,
            'message' => 'Product not found',
        );
    }

    $product_data = array(
        'id' => $product_id,
        'name' => $product->get_name(),
        'permalink' => $product->get_permalink(),
        'images' => array(),
        'meta' => array(),
        'price' => $product->get_price(),
        'regular_price' => $product->get_regular_price(),
        'sale_price' => $product->get_sale_price(),
        'description' => $product->get_description(),
        'attributes' => $product->get_attributes(),
        'related_products' => array(),
        'recommended_products' => array(),
        'in_wishlist' => false, // Initialize in_wishlist as false by default
    );

    $product_images = $product->get_gallery_image_ids();

    foreach ($product_images as $image_id) {
        $image_url = wp_get_attachment_image_src($image_id, 'full');
        if ($image_url) {
            $product_data['images'][] = $image_url[0];
        }
    }

    $image_id = $product->get_image_id();
    $image_status = wp_get_attachment_image_url($image_id, 'full');
    $product_data['main_image'] = ($image_status != NULL) ? wp_get_attachment_image_url($image_id, 'full') : $image_not_available;

    // Get additional metadata
    $product_meta = get_post_meta($product_id);
    foreach ($product_meta as $meta_key => $meta_value) {
       // $product_data['meta'][$meta_key] = $meta_value[0];
    }


    /*

    // Get variations if product is variable
    if ($product->is_type('variable')) {
        $variation_data = array();
        $variations = $product->get_available_variations();

         $original_color_name = $product->get_attribute('pa_color');

        foreach ($variations as $variation) {
            $variation_data[] = array(
                'id' => $variation['variation_id'],
                'attributes' => $variation['attributes'],
                'price' => $variation['display_price'],
                'regular_price' => $variation['display_regular_price'],
                
                'original_color_name'  =>   $original_color_name ,
                // Add any other variation details you need
            );
        }

        $product_data['variations'] = $variation_data;
    }
    */
    

    // Get variations if product is variable
    if ($product->is_type('variable')) {
        $variation_data = array();
        $variations = $product->get_available_variations();
        


        
        
        // echo "<pre>";
        // print_r($variations);
        //   echo "</pre>";
           

        foreach ($variations as $variation) {
            $variation_id = $variation['variation_id'];
            $variation_product = wc_get_product($variation_id);
            $variation_image_id = $variation_product->get_image_id();
            $variation_image_url = ($variation_image_id != 0) ? wp_get_attachment_image_url($variation_image_id, 'full') : $image_not_available;

    $original_color_name = $variation_product->get_attribute('pa_color');

            $variation_data[] = array(
                'id' => $variation_id,
                'attributes' => $variation['attributes'],
                'price' => $variation['display_price'],
                'regular_price' => $variation['display_regular_price'],
                'image' => $variation_image_url,
                'original_color_name'  =>   $original_color_name ,
                
                'color_code'  =>   '#FFFF' ,


                // Add any other variation details you need
            );
        }

        $product_data['variations'] = $variation_data;
        
        $product_data['type_product'] = 'variable';
        
    }else{
        $product_data['type_product'] = 'simple';
    }



            
            global $wpdb;
            // Check if the record already exists
            $d = "SELECT * FROM `wp_yith_wcwl` WHERE `prod_id` = '$product_id' AND `user_id` = '" . $_REQUEST['user_id'] . "'";
            $existing_record = $wpdb->get_row($d);
            if ($wpdb->num_rows > 0) {
                $product_data['wish_status'] = true;
            } else {
                $product_data['wish_status'] = false;
            }
            




    // Get related products
    $related_ids = $product->get_cross_sell_ids();
    $related_products = array();

    foreach ($related_ids as $related_id) {
        $related_product = get_product_by_id($related_id, $image_not_available);
        if (!isset($related_product['error'])) {
            $related_products[] = $related_product;
        }
    }

    $product_data['related_products'] = $related_products;

    // Get recommended products
    $recommended_ids = $product->get_upsell_ids();
    $recommended_products = array();

    foreach ($recommended_ids as $recommended_id) {
        $recommended_product = get_product_by_id($recommended_id, $image_not_available);
        if (!isset($recommended_product['error'])) {
            $recommended_products[] = $recommended_product;
        }
    }

    $product_data['recommended_products'] = $recommended_products;

    global $wpdb;

    $wishlist_table = 'wp_' . 'yith_wcwl';

    $in_wishlist = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $wishlist_table WHERE user_id = %d AND prod_id = %d",
            $user_id,
            $product_id
        )
    );

    //echo $wpdb->last_query;

    $product_data['in_wishlist'] = ($in_wishlist > 0);
    
    
     $sql = "SELECT * FROM `wp_custom_faq` WHERE `product_id` ='$product_id'";
    
     $faq_array = $wpdb->get_results($sql,ARRAY_A);
         
    
    $faq = array();
    
     foreach ($faq_array as $faq_array_in) {
            $faq[] = $faq_array_in;
        
    }   
    
    $product_data['faq'] = $faq;
    
    
      // Get reviews for the product
    $args = array(
        'post_id' => $product_id,
        'status'  => 'approve',
        'number'  => -1, // Get all reviews
    );

    $comments = get_comments($args);

    foreach ($comments as $comment) {
        $review = array(
            'author' => $comment->comment_author,
            'content' => $comment->comment_content,
            'image' => "https://w7.pngwing.com/pngs/831/88/png-transparent-user-profile-computer-icons-user-interface-mystique-miscellaneous-user-interface-design-smile-thumbnail.png",

            'date' => $comment->comment_date,
            'rating' => get_comment_meta($comment->comment_ID, 'rating', true),
        );

        $product_data['reviews'][] = $review;
    }


    $product_data['good'] = "<div>
<h2>What is Lorem Ipsum?</h2>
<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
</div>
<div>
<h2>Why do we use it?</h2>
<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
</div>";

    return $product_data;
}

// Check if a product ID is provided in the request
if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];

    // Get product information for the specified ID
    $product = get_product_by_id($product_id, $image_not_available);

    if ($product['error']) {
        $response = array(
            'result' => [],
            'message' => 'unsuccess',
            'status' => '0'
        );
    } else {
        $response = array(
            'result' => $product,
            'message' => 'Success',
            'status' => '1'
        );
    }

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array(
        'result' => [],
        'message' => 'unsuccess',
        'status' => '0'
    );

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}