<?php
require_once ('../wp-config.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
// Create an instance of PHPMailer class
$mail = new PHPMailer;
//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);
$email = $_REQUEST['email'];
$check_login = $wpdb->get_results("SELECT  *  FROM  `wp_users`  WHERE  `user_email`  =  '$email' ");
$login_user_array1 = json_decode(json_encode($check_login), true);
$user_id = $login_user_array1[0]['ID'];
$user_id = $login_user_array1[0]['ID'];
$name = $login_user_array1[0]['user_login'];
if ($check_login) {
    // user ke mobile no pr otp send krna he
    $otp = '1234';
    $checkdata = $wpdb->get_results("SELECT * FROM `wp_usermeta` WHERE `user_id` = '$user_id' AND `meta_key` = 'signupotp' ");
    $login_user_array = json_decode(json_encode($checkdata), true);
    $id = $login_user_array[0]['umeta_id'];
    //   print_r($id);die;
    if ($checkdata) {
        $wpdb->get_results("UPDATE `wp_usermeta` SET `meta_value`= '$otp' WHERE `user_id` = '$user_id' AND `umeta_id` = '$id' ");
        $to = $email;
        $subject = "VERIFYCATION OTP";
        $content = "<div style='max-width: 600px; width: 100%; margin-left: auto; margin-right: auto;'>
    <header style='color: #fff; width: 100%;'>
    
   </header>

   <div style='margin-top: 10px; padding-right: 10px; 
   padding-left: 125px;
   padding-bottom: 20px;'>
   <hr>

   <p>Name :  $name</p>

   <p>Email : $email</p>

   <p>Your Otp is : $otp</p>
   <hr>

   <p>Warm Regards<br> Ebx Ecommerce <br>Support Team</p>

 </div>
</div>

</div>";
        // $headers = "From: amir@technorizen.com" . "\r\n";
        // $headers.= "MIME-Version: 1.0" . "\r\n";
        // $headers.= "Content-type:text/html;charset=UTF-8" . "\r\n";
        // $status = wp_mail($to, $subject, $content,$headers);
        //Server settings
        // $mail->SMTPDebug = SMTP::DEBUG_SERVER;    //Enable verbose debug output
        //$mail->isSMTP();                                            //Send using SMTP
        $mail->Host = 'smtp.gmail.com'; //Set the SMTP server to send through
        $mail->SMTPAuth = true; //Enable SMTP authentication
        $mail->Username = 'justtest@technorizen.com'; //SMTP username
        $mail->Password = 'justtest@123'; //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; //Enable implicit TLS encryption
        $mail->Port = 587; //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        //Recipients
        $mail->setfrom('amir@technorizen.com', 'Mailer');
        $mail->addaddress($email, 'Ecommerce'); //Add a recipient
        //Content
        $mail->isHTML(true); //Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body = $content;
        // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        $mail->send();
        // echo 'Message has been sent';die;
        $msg['result'] = $login_user_array1[0];
        $msg["message"] = "success";
        $msg["status"] = "1";
        header('Content-type:application/json');
        echo json_encode($msg);
    } else {
        $msg['result'] = (object)[];
        $msg["message"] = "No Data Found";
        $msg["status"] = "0";
        header('Content-type:application/json');
        echo json_encode($msg);
    }
    // SELECT * FROM `dNvuK_usermeta` WHERE `umeta_id` = '320' AND `user_id` = 21 AND `meta_key` = 'otp'
    
} else {
    $msg['result'] = "User Id Not Found";
    $msg["message"] = "No Data Found";
    $msg["status"] = "0";
    header('Content-type:application/json');
    echo json_encode($msg);
}
?>