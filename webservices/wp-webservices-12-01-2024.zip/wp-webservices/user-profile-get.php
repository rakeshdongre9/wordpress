<?php

///https://technorizen.com/_angotech_homol1/wp-webservices/user-profile-get.php?user_id=1

require_once('../wp-config.php'); // replace with your WordPress installation path

// Check if a user ID is provided in the request
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Get user data
    $user_data = get_userdata($user_id);
    $user_meta = get_user_meta($user_id);
    
    // Get shipping meta data
    $shipping_meta = array(
        'shipping_first_name' => get_user_meta($user_id, 'shipping_first_name', true),
        'shipping_last_name' => get_user_meta($user_id, 'shipping_last_name', true),
        'shipping_phone' => get_user_meta($user_id, 'shipping_phone', true),
        'shipping_email' => get_user_meta($user_id, 'shipping_email', true),
        'shipping_address_1' => get_user_meta($user_id, 'shipping_address_1', true),
        'shipping_address_2' => get_user_meta($user_id, 'shipping_address_2', true),
        'shipping_city' => get_user_meta($user_id, 'shipping_city', true),
        'shipping_state' => get_user_meta($user_id, 'shipping_state', true),
        'shipping_postcode' => get_user_meta($user_id, 'shipping_postcode', true),
        'shipping_country' => get_user_meta($user_id, 'shipping_country', true),
    );
    
    

     $image =   home_url() . "/wp-uploads/user/" . get_user_meta($user_id, 'image', true);
     
     $mobile =  get_user_meta($user_id, 'mobile', true);

      

      

    if ($user_data === false) {
        $response = array(
            'result' => [],
            'message' => 'User not found',
            'status' => '0'
        );
    } else {
        $response = array(
            'result' => array(
                'user_id' => $user_data->ID,
                'username' => $user_data->user_login,
                'email' => $user_data->user_email,
                'first_name' => $user_data->first_name,
                'last_name' => $user_data->last_name,
                
                'mobile' => $mobile,
                'image' => $image,

                
                //'meta' => $user_meta,
                'shipping_meta' => $shipping_meta,
            ),
            'message' => 'Success',
            'status' => '1'
        );
    }

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array(
        'result' => [],
        'message' => 'User ID not provided',
        'status' => '0'
    );

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}
?>