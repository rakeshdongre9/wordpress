<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

//https://technorizen.com/_angotech_homol1/wp-webservices/chat_insert_files.php?sender_id=3&receiver_id=2&message=hi&files[]=

require_once "../wp-config.php";

$sender_id = $_REQUEST['sender_id'];
$receiver_id = $_REQUEST['receiver_id'];
$message = $_REQUEST['message'];
// $chat_files_name = $_REQUEST['chat_files_name'];
// $chat_files_chat_id =$_REQUEST['chat_files_chat_id'];

$date_time = date('Y-m-d H:i:s');
$file_name = $_REQUEST['message'];

// Check if there are any files attached
if (isset($_FILES['files']) && !empty($_FILES['files'])) {
    $file_names = $_FILES['files']['name'];
    $file_count = count($file_names);

    for ($i = 0; $i < $file_count; $i++) {
        $file_name = explode(".",$file_names[$i])[1];
        $file_tmp = $_FILES['files']['tmp_name'][$i];

        // Move the file to a desired directory/home/littpandafm/public_html/wp-content/plugins/webservice/chat-insert-files.php
        

        
        $target_directory = '/home2/technz1m/public_html/_angotech_homol1/wp-uploads/chat/';
        
        $file_name = "CHAT-" . rand(1111,9999) . "-" .  rand(1111,9999) . ".". $file_name;
        
        $target_file = $target_directory .  $file_name;

        move_uploaded_file($file_tmp, $target_file);

        // Detect file type based on the extension
        $file_extension = pathinfo($target_file, PATHINFO_EXTENSION);
        $chat_type = '';

        if (in_array($file_extension, ['jpg', 'jpeg', 'png', 'gif'])) {
            $chat_type = 'IMAGE';
        } elseif (in_array($file_extension, ['mp4', 'mov', 'avi', 'wmv'])) {
            $chat_type = 'VIDEO';
        } else {
            // Handle unsupported file types or error condition
            // You can add appropriate error handling code here
             $chat_type = 'IMAGE';

        }

        // Insert the text message into the database
         $sql = "INSERT INTO `dNvuK_chat` (`chat_receiver_id`, `chat_sender_id`, `chat_seen_status`, `chat_text`, `chat_date_time`, `chat_type`) VALUES ('$receiver_id', '$sender_id', 'UNSEEN', '$message', '$date_time', '$chat_type');";

        $check_events = $wpdb->query($sql);

        if ($check_events) {
            // $chat_id = $wpdb->insert_id;

            // Insert file details into the database
            $file_sql = "INSERT INTO `dNvuK_chat_files` (`chat_files_name`, `chat_files_chat_id`) VALUES ('$file_name', '48');";

            $wpdb->query($file_sql);
            
            $video_id = $wpdb->insert_id;
            
            $sql = "UPDATE `dNvuK_chat` SET `chat_post_id`='$video_id' WHERE `chat_id` = '$chat_id'";
            
            $wpdb->query($sql);

            
            
        }
    }
}

if ($check_events) {
    $msg["result"] = "1";
    $msg["message"] = "successful";
    $msg["status"] = "1";
    header("Content-type:application/json");
    echo json_encode($msg);
    // die();
} else {
    $msg["result"] = [];
    $msg["message"] = "unsuccessful";
    $msg["status"] = "0";
    header("Content-type: application/json");
    echo json_encode($msg);
    
}

?>
