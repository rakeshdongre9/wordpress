<?php

include('../wp-config.php');

$term_id = 52; // Replace with the desired term ID
$taxonomy = 'pa_color'; // Replace with the appropriate taxonomy

$term = get_term($term_id, $taxonomy);

print_r($term);

if ($term && !is_wp_error($term)) {
    $term_name = $term->name;
    $term_slug = $term->slug;
    $term_description = $term->description;

    // Retrieve the color code using the term ID and meta key 'color'
    $color_code = get_term_meta($term_id, 'product_attribute_color', true);

    // Output the attribute data
    echo "Term ID: $term_id <br>";
    echo "Term Name: $term_name <br>";
    echo "Term Slug: $term_slug <br>";
    echo "Term Description: $term_description <br>";
    echo "Color Code: $color_code <br>";
} else {
    echo "Term not found or error occurred.";
}


die;

$array = [
    [
        "black-leather-de" => [
            "color_origin" => "Black Leather",
            "color_name" => "black-leather-de",
            "color_code" => "FFFFFF",
            "color_size" => "m",
            "color_image" => "https://i0.wp.com/technorizen.com/_angotech_homol1/wp-content/uploads/2023/03/icons8-heart-health-50-2.png?fit=50%2C50&ssl=1"
        ]
    ],
    [
        "blue-de" => [
            "color_origin" => "azul",
            "color_name" => "blue-de",
            "color_code" => "FFFFFF",
            "color_size" => "m",
            "color_image" => "https://i0.wp.com/technorizen.com/_angotech_homol1/wp-content/uploads/2023/03/icons8-heart-health-48-e1679494743336.png?fit=48%2C48&ssl=1"
        ]
    ],
    [
        "blue-de" => [
            "color_origin" => "azul",
            "color_name" => "blue-de",
            "color_code" => "FFFFFF",
            "color_size" => "l",
            "color_image" => "https://i0.wp.com/technorizen.com/_angotech_homol1/wp-content/uploads/2023/03/61kwMMaGMhL._AC_UL320_.jpg?fit=320%2C290&ssl=1"
        ]
    ],
    [
        "black-leather-de" => [
            "color_origin" => "Black Leather",
            "color_name" => "black-leather-de",
            "color_code" => "FFFFFF",
            "color_size" => "l",
            "color_image" => "https://i0.wp.com/technorizen.com/_angotech_homol1/wp-content/uploads/2023/03/H5031436ab0964ba38bde75a8b5630e3bh.png_250x250.webp?fit=250%2C215&ssl=1"
        ]
    ]
];

$uniqueElements = [];

foreach ($array as $item) {
    foreach ($item as $key => $value) {
            $uniqueElements[$key][$key][] = $value;
        
    }
}

//print_r($uniqueElements);

$uniqueElements = array_values($uniqueElements);


echo "<pre>";
print_r($uniqueElements);
echo "</pre>";



















die;



require_once('../wp-config.php'); // replace with your WordPress installation path

//https://technorizen.com/_angotech_homol1/wp-webservices/test.php


$cart_items = WC()->cart->get_cart();

if (isset($cart_items['a043424b3cab0baa54c1d5544a4506c4'])) {
    $cart_item = $cart_items['a043424b3cab0baa54c1d5544a4506c4'];

    // Access the cart item data
    $product_id = $cart_item['product_id'];
    $variation_id = $cart_item['variation_id'];
    $variation = $cart_item['variation'];
    $quantity = $cart_item['quantity'];
    // Access more cart item data as needed

    // Output the cart item data
    echo "Product ID: " . $product_id . "<br>";
    echo "Variation ID: " . $variation_id . "<br>";
    echo "Variation: " . print_r($variation, true) . "<br>";
    echo "Quantity: " . $quantity . "<br>";
    // Output more cart item data as needed
} else {
    echo "Cart item with the provided key not found.";
}











die;


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;


require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php'; 

//require '/root/vendor/autoload.php';

 
// Create an instance of PHPMailer class 
$mail = new PHPMailer;

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);


    //Server settings
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;    //Enable verbose debug output
    //$mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'justtest@technorizen.com';                     //SMTP username
    $mail->Password   = 'justtest@123';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setfrom('amir@technorizen.com', 'Mailer');
    $mail->addaddress('ajayrajputtechno2011@gmail.com', 'rakesh dongre');     //Add a recipient



    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';die;
    
    
    
    
    
    
?>


