<?php

//https://technorizen.com/_angotech_homol1/wp-webservices/recent-product-visited-list-get.php?user_id=1

require_once('../wp-config.php'); // replace with your WordPress installation path
global $wpdb;

function get_product_by_id($product_id, $image_not_available) {
    $product = wc_get_product($product_id);

    if (!$product) {
        return array(
            'error' => true,
            'message' => 'Product not found',
        );
    }

    $product_data = array(
        'id' => $product_id,
        'name' => $product->get_name(),
        'permalink' => $product->get_permalink(),
        'images' => array(),
        'meta' => array(),
        'price' => $product->get_price(),
        'regular_price' => $product->get_regular_price(),
        'sale_price' => $product->get_sale_price(),
        'description' => $product->get_description(),
        'attributes' => $product->get_attributes(),
    );

    $product_images = $product->get_gallery_image_ids();

    foreach ($product_images as $image_id) {
        $image_url = wp_get_attachment_image_src($image_id, 'full');
        if ($image_url) {
            $product_data['images'][] = $image_url[0];
        }
    }

    $image_id = $product->get_image_id();
    $image_status = wp_get_attachment_image_url($image_id, 'full');
    $product_data['main_image'] = ($image_status != NULL) ? wp_get_attachment_image_url($image_id, 'full') : $image_not_available;

    // Get additional metadata
    $product_meta = get_post_meta($product_id);
    foreach ($product_meta as $meta_key => $meta_value) {
        $product_data['meta'][$meta_key] = $meta_value[0];
    }

    return $product_data;
}

// Check if a user ID is provided in the request
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Retrieve the recent_visits items from the YITH recent_visits table
    $table_name = 'wpuo_recent_visits_list';
    $recent_visits_items = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d", $user_id));

    if (empty($recent_visits_items)) {
        $response = array(
            'message' => 'Recent Product list is empty',
            'status' => '1'
        );
    } else {
        $recent_visits = array();
        $image_not_available = 'https://example.com/image-not-available.jpg'; // Replace with your image URL for when the image is not available

        foreach ($recent_visits_items as $item) {
            $product_id = $item->prod_id;
            $product = get_product_by_id($product_id, $image_not_available);
            

            $product['user_id'] = $item->user_id;

            $recent_visits[] = $product;
        }

        $response = array(
            'recent_visits' => $recent_visits,
            'message' => 'Recent Product list retrieved successfully',
            'status' => '1'
        );
    }

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array(
        'recent_visits' => array(),
        'message' => 'User ID not provided',
        'status' => '0'
    );

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}
?>