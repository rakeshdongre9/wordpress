<?php

require_once('../wp-config.php'); // replace with your WordPress installation path


function generate_token($length = 12) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $token = '';

    for ($i = 0; $i < $length; $i++) {
        $random_index = mt_rand(0, strlen($characters) - 1);
        $token .= $characters[$random_index];
    }

    return $token;
}


global $wpdb;

// Check if a user ID and product ID are provided in the request
if (isset($_GET['user_id']) && isset($_GET['id'])) {
    $user_id = $_GET['user_id'];
    $product_id = $_GET['id'];

    // Remove the wishlist product from the YITH Wishlist table
    $table_name = 'wp_yith_wcwl';
    
    
    
       $generate_token =  generate_token(12);
               
       $sql = "SELECT * FROM `wp_yith_wcwl_lists` WHERE user_id = '$user_id'";
       $wish_data = $wpdb->get_row($sql,ARRAY_A);
    
      if($wpdb->num_rows>0){
          
            $insert_id =  $wish_data['ID'];
          
      }else{
          
            $sql="INSERT INTO `wp_yith_wcwl_lists`( `user_id`, `wishlist_token`,`is_default`, `session_id`, `wishlist_name`, `expiration` ) VALUES ('$user_id','$generate_token','1','','','0000-00-00 00:00:00')";
            $wpdb->query($sql);
            
            $insert_id = $wpdb->insert_id;

      }
      
      
       $sql = "SELECT * FROM `wp_yith_wcwl` WHERE `wishlist_id`='$insert_id' and `user_id` ='$user_id'  and `prod_id`='$product_id'";
       $wish_data = $wpdb->get_row($sql,ARRAY_A);
    
      if($wpdb->num_rows>0){
          
          //echo "already exists";
          
      }else{
          
         // echo "no";

      }
      
      
      

    // Check if the wishlist product already exists for the user
    $existing_product = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE user_id = %d AND prod_id = %d",
        $user_id,
        $product_id
    ));

    if ($existing_product) {
        $wpdb->delete($table_name, array('user_id' => $user_id, 'prod_id' => $product_id));
        
        // Return a success message for deleting the existing product
        $response = array(
            'message' => 'Existing wishlist product deleted successfully',
            'status' => '1'
        );
    } else {
        // Add the wishlist product to the YITH Wishlist table
        $wpdb->insert($table_name, array(
            'user_id' => $user_id,
            'prod_id' => $product_id
        ));
        
        // Return a success message for adding the new product
        $response = array(
            'message' => 'New wishlist product added successfully',
            'status' => '1'
        );
    }

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array(
        'message' => 'User ID or product ID not provided',
        'status' => '0'
    );

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}
?>