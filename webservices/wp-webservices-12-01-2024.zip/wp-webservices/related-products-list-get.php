<?php
// https://technorizen.com/_angotech_homol1/wp-webservices/related-products-list-get.php?user_id=1

require_once('../wp-config.php'); // replace with your WordPress installation path
global $wpdb;

function get_related_products($product_id) {
    // Replace this logic with your own to fetch related products
    // You can use WooCommerce functions to determine related products based on your criteria
    // For example, you can use wc_get_related_products() or custom queries

    // Example: Get related products based on product categories
    $related_product_ids = wc_get_related_products($product_id);

    $related_products = array();
    foreach ($related_product_ids as $related_product_id) {
        $related_product = get_product_by_id($related_product_id);
        $related_products[] = $related_product;
    }

    return $related_products;
}

function get_product_by_id($product_id) {
    // Use your existing function to retrieve product data here
    // This function should return an array of product data
    // Similar to the get_product_by_id function in your previous code
    // ...

    return $product_data;
}

// Check if a user ID is provided in the request
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Retrieve the recent_visits items from the YITH recent_visits table
    $table_name = 'wpuo_recent_visits_list';
    $recent_visits_items = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d", $user_id));

    if (empty($recent_visits_items)) {
        $response = array(
            'message' => 'Recent Product list is empty',
            'status' => '1'
        );
    } else {
        $recent_visits = array();
        $image_not_available = 'https://example.com/image-not-available.jpg'; // Replace with your image URL for when the image is not available

        foreach ($recent_visits_items as $item) {
            $product_id = $item->prod_id;

            // Get related products based on the current product
            $related_products = get_related_products($product_id);

            $response_item = array(
                'user_id' => $item->user_id,
                'product_id' => $product_id,
                'related_products' => $related_products,
            );

            $recent_visits[] = $response_item;
        }

        $response = array(
            'recent_visits' => $recent_visits,
            'message' => 'Related Products list retrieved successfully',
            'status' => '1'
        );
    }

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
} else {
    $response = array(
        'recent_visits' => array(),
        'message' => 'User ID not provided',
        'status' => '0'
    );

    // Output the result as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    die;
}
?>